# -*- coding: utf-8 -*-
import sys
import six
import os
import base64
if six.PY2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
from fasthttp import req
import re
import xml.etree.ElementTree as ET
from datetime import datetime
import time
import sqlite3
from datetime import datetime, timedelta
import threading
try:
    from lib import proxy
except:
    import proxy
try:
    from lib.scraper import oneplay
except:
    from scraper import oneplay  
try:
    from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
    version_oneplay = '02.11.2023'
    handle = int(sys.argv[1])
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    addonid = addon.getAddonInfo('id')
    icon = addon.getAddonInfo('icon')
    translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
    home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
    profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
    listitem = xbmcgui.ListItem
    adddirectory = xbmcplugin.addDirectoryItem
    enddirectory = xbmcplugin.endOfDirectory
    content = xbmcplugin.setContent
    player = xbmcplugin.setResolvedUrl
    dialog = xbmcgui.Dialog()
    keyboard = xbmc.Keyboard
    fanart_default = os.path.join(home, 'fanart.jpg')
    epgEnabled = addon.getSetting('exibirepg')
    adult = addon.getSetting('adult')
    if not os.path.exists(profile):
        try:
            os.mkdir(profile)
        except:
            pass
    epg_version = os.path.join(profile, 'epg_version.txt')
    epg_file = os.path.join(profile, 'epg.xml')
    check_pix = os.path.join(profile, 'check.txt')
    cache_db =  os.path.join(profile, 'cache.db')         
except:
    addonname = 'ONEPLAY'     

def request_cache(url,headers={}):
    try:
        conn = sqlite3.connect(cache_db)
        cursor = conn.cursor()

        # Verifique se a tabela já existe
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cache'")
        table_exists = cursor.fetchone()

        if not table_exists:
            # Crie a tabela para armazenar o cache, se não existir
            cursor.execute('''
                CREATE TABLE cache (
                    url TEXT PRIMARY KEY,
                    content TEXT,
                    timestamp INTEGER
                )
            ''')
            conn.commit()        

        # Verifique se a URL já está em cache
        cursor.execute('SELECT * FROM cache WHERE url = ?', (url,))
        cached_data = cursor.fetchone()

        if cached_data:
            url, content, timestamp = cached_data
            last_fetched = datetime.fromtimestamp(timestamp)
            if datetime.now() - last_fetched < timedelta(hours=2):
                return content
        if headers:
            response = req.get(url,headers=headers,replace_headers=True)
        else:
            response = req.get(url)

        if response.status_code == 200:
            content = response.text

            # Atualize o cache
            if cached_data:
                cursor.execute('UPDATE cache SET content = ?, timestamp = ? WHERE url = ?', (content, datetime.now().timestamp(), url))
            else:
                cursor.execute('INSERT INTO cache VALUES (?, ?, ?)', (url, content, datetime.now().timestamp()))

            conn.commit()
            conn.close()

            return content
        else:
            conn.close()
            return ''
    except:
        return ''        
 



def icons(name):
    try:
        icon = os.path.join(home, 'resources', 'images', '%s.png'%name)
    except:
        icon = ''
    return icon

try:
    base = sys.argv[0]
except:
    base = ''

def set_content(value='video'):
    try:
        content(handle, value)
    except:
        pass

def end(cache=True):
    try:
        enddirectory(handle,cacheToDisc=cache)
    except:
        pass

def set_view(name):
    mode = {'Wall': '500',
            'List': '50',
            'Poster': '51',
            'Shift': '53',
            'InfoWall': '54',
            'WideList': '55',
            'Fanart': '502'
            }
    try:
        xbmc.executebuiltin('Container.SetViewMode(%s)'%mode[name])
    except:
        pass

def open_settings():
    try:
        addon.openSettings()
    except:
        pass

def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    try:
        if iconimage == '':
            iconimage = icon
        elif iconimage == 'INFO':
            iconimage = xbmcgui.NOTIFICATION_INFO
        elif iconimage == 'WARNING':
            iconimage = xbmcgui.NOTIFICATION_WARNING
        elif iconimage == 'ERROR':
            iconimage = xbmcgui.NOTIFICATION_ERROR
        dialog.notification(heading, message, iconimage, time, sound=sound)
    except:
        pass

def extract(path_zip, dest_folder):
    if six.PY3:
        import zipfile
    else:
        try:
            from lib import zipfile2 as zipfile
        except:
            import zipfile2 as zipfile
    try:
        zin = zipfile.ZipFile(path_zip, 'r')
        zin.extractall(dest_folder)
    except Exception as e:
        pass

def notify(msg):
    infoDialog(msg, iconimage='INFO')

def update_oneplay():
    try:
        from lib.scraper import oneplay
    except:
        from scraper import oneplay
    try:
        url_zip, ver = oneplay().get_oneplay_version()
        if url_zip and ver:
            if version_oneplay != ver:
                packages = translate('special://home/addons/packages')
                dest_final = translate('special://home/addons/'+addonid)
                notify('Atualizando...')
                import ntpath
                filename = ntpath.basename(url_zip)
                dest=os.path.join(packages, filename)
                with open(dest, 'wb') as f:
                    res = req.get(url_zip,headers=oneplay().headers,replace_headers=True)
                    for chunk in res.iter_content(chunk_size=1024):
                        f.write(chunk)
                if os.path.exists(dest):
                    extract(dest,dest_final)
                    try:
                        os.remove(dest)
                    except:
                        pass
                msg = '[B][COLOR aquamarine]Versao: %s[/COLOR][/B]'%ver
                notify(msg)
    except:
        pass       

def check_epg():
    try:
        from lib.scraper import oneplay
    except:
        from scraper import oneplay
    url_version = oneplay().epg_url_version
    url_epg = oneplay().url_epg
    if not os.path.exists(epg_version):
        r = req.get(url_version)
        src = r.text
        with open(epg_version, 'w') as f:
            f.write(src)
        with open(epg_file, 'wb') as f:
            notify('BAIXANDO EPG AGUARDE...')
            res = req.get(url_epg,headers=oneplay().headers,replace_headers=True)
            for chunk in res.iter_content(chunk_size=1024):
                f.write(chunk)         
    else:
        ver = ''
        ver2 = '' 
        with open(epg_version, 'r') as f:
            src = f.read()
            ver += re.findall(r"\d+", src)[0]
        r = req.get(url_version)
        src = r.text
        ver2 += re.findall(r"\d+", src)[0]
        if int(ver2) > int(ver):
            with open(epg_version, 'w') as f:
                f.write(src)                
            down = True
        else:
            down = False
        if down:
            with open(epg_file, 'wb') as f:
                notify('BAIXANDO EPG AGUARDE...')
                res = req.get(url_epg,headers=oneplay().headers,replace_headers=True)
                for chunk in res.iter_content(chunk_size=1024):
                    f.write(chunk)

def epgParseData():
    try:
        check_epg()
        notify('AGUARDE EPG...')
        return ET.parse(epg_file).getroot()
    except:
        notify('FALHA AO USAR EPG...')
        return None

def getID_EPG(channel):
    if re.search("A&E",channel,re.IGNORECASE): # ok
        channel_id = 'AEBrazil.br'
    elif re.search("AMC",channel,re.IGNORECASE): #ok
        channel_id = 'AMCBrazil.br'
    elif re.search("Animal Planet",channel,re.IGNORECASE): # ok
        channel_id = 'AnimalPlanetBrazil.br'
    elif re.search("Arte 1",channel,re.IGNORECASE): # ok
        channel_id = 'Arte1.br'
    elif re.search("AXN",channel,re.IGNORECASE): # ok
        channel_id = 'AXNBrazil.br'
    elif re.search("Baby TV",channel,re.IGNORECASE) or re.search("BabyTV",channel,re.IGNORECASE):
        channel_id = 'BabyTV.br'
    elif re.search("Band",channel,re.IGNORECASE) and not re.search("Band News",channel,re.IGNORECASE) and not re.search("Band Sports",channel,re.IGNORECASE):
        channel_id = 'BandSaoPaulo.br' # ok
    elif re.search("Band News",channel,re.IGNORECASE): # ok
        channel_id = 'BandNews.br'
    elif re.search("Band Sports",channel,re.IGNORECASE): # ok
        channel_id = 'BandSports.br'
    elif re.search("BIS",channel,re.IGNORECASE):
        channel_id = 'Bis.br'
    elif re.search("Boomerang",channel,re.IGNORECASE): #ok
        channel_id = 'BoomerangBrazil.br'
    elif re.search("Canal Brasil",channel,re.IGNORECASE):
        channel_id = 'CanalBrasil.br'
    elif re.search("Cancao Nova",channel,re.IGNORECASE) or re.search("Canção Nova",channel,re.IGNORECASE):
        channel_id = 'TVCancaoNova.br'
    elif re.search("Cartoon Network",channel,re.IGNORECASE): # ok
        channel_id = 'CartoonNetworkBrazil.br'
    elif re.search("Cinemax",channel,re.IGNORECASE):
        channel_id = 'CinemaxBrazil.br'
    elif re.search("Combate",channel,re.IGNORECASE):
        channel_id = 'Combatehd.br'
    elif re.search("Comedy Central",channel,re.IGNORECASE): # ok
        channel_id = 'ComedyCentralBrazil.br'
    elif re.search("Cultura",channel,re.IGNORECASE):
        channel_id = 'TVCulturaNacional.br'
    elif re.search("Curta!",channel,re.IGNORECASE) or re.search("Curta",channel,re.IGNORECASE):
        channel_id = 'Curta.br'
    elif re.search("Discovery Channel",channel,re.IGNORECASE): # ok
        channel_id = 'DiscoveryChannelBrazil.br'
    elif re.search("Discovery Civilization",channel,re.IGNORECASE):
        channel_id = 'DiscoveryCivilization.br'
    elif re.search("Discovery Home Health",channel,re.IGNORECASE) or re.search("Discovery H&H",channel,re.IGNORECASE):
        channel_id = 'DiscoveryHomeHealthBrazil.br'
    elif re.search("Discovery Kids",channel,re.IGNORECASE):
        channel_id = 'DiscoveryKidsBrazil.br'
    elif re.search("Discovery Science",channel,re.IGNORECASE):
        channel_id = 'DiscoveryScienceBrazil.br'
    elif re.search("Discovery Theater",channel,re.IGNORECASE):
        channel_id = 'DiscoveryTheaterBrazil.br'
    elif re.search("Discovery Turbo",channel,re.IGNORECASE): # ok
        channel_id = 'DiscoveryTurboBrazil.br'
    elif re.search("Discovery World",channel,re.IGNORECASE):
        channel_id = 'DiscoveryWorldBrazil.br'
    elif re.search("Disney Junior",channel,re.IGNORECASE) or re.search("Disney Jr",channel,re.IGNORECASE):
        channel_id = 'Disneyjrhd.br'
    elif re.search("Disney XD",channel,re.IGNORECASE):
        channel_id = 'Disneyxd.br'
    elif re.search("Disney",channel,re.IGNORECASE) and not re.search("Cine",channel,re.IGNORECASE) or re.search("Disney Channel",channel,re.IGNORECASE): # ok
        channel_id = 'DisneyChannelBrazil.br'
    elif re.search("E!",channel,re.IGNORECASE):
        channel_id = 'EBrazil.br'
    elif re.search("Espn Extra",channel,re.IGNORECASE):
        channel_id = 'ESPNExtraBrazil.br'
    elif re.search("ESPN Brasil",channel,re.IGNORECASE):
        channel_id = 'ESPNBrazil.br' 
    elif re.search("ESPN 2",channel,re.IGNORECASE): # ok
        channel_id = 'ESPN.us'
    elif re.search("ESPN",channel,re.IGNORECASE): # ok
        channel_id = 'ESPNExtraBrazil.br'                              
    elif re.search("FishTV",channel,re.IGNORECASE) or re.search("Fish TV",channel,re.IGNORECASE):
        channel_id = 'FishTV.br'
    elif re.search("Food Network",channel,re.IGNORECASE):
        channel_id = 'FoodNetworkBrazil.br'
    elif re.search("Fox News",channel,re.IGNORECASE):
        channel_id = 'FoxNewsChannel.us'  
    elif re.search("Fox Sports 2",channel,re.IGNORECASE):
        channel_id = 'FoxSports2Brazil.br' 
    elif re.search("ESPN 4",channel,re.IGNORECASE) or re.search("Fox Sports",channel,re.IGNORECASE):
        channel_id = 'FoxSportsBrazil.br'                                    
    elif re.search("Futura",channel,re.IGNORECASE):
        channel_id = 'CanalFutura.br'
    elif re.search("FX",channel,re.IGNORECASE) and not re.search("US",channel,re.IGNORECASE):
        channel_id = 'FXBrazil.br'
    elif re.search("Film & Arts",channel,re.IGNORECASE):
        channel_id = 'FilmArtsBrazil.br'
    elif re.search("Globo Brasilia",channel,re.IGNORECASE) or re.search("Globo Brasília",channel,re.IGNORECASE):
        channel_id = 'TVGloboBrasilia.br'
    elif re.search("Globo Campinas",channel,re.IGNORECASE) or re.search("Globo EPTV Campinas",channel,re.IGNORECASE):
        channel_id = 'GloboEPTVCampinas.br'
    elif re.search("Globo Minas",channel,re.IGNORECASE):
        channel_id = 'Globominas.br'
    elif re.search("Globo News",channel,re.IGNORECASE):
        channel_id = 'GloboNews.br'
    elif re.search("Globo RJ",channel,re.IGNORECASE):
        channel_id = 'TVGloboRiodeJaneiro.br'
    elif re.search("Globo SP",channel,re.IGNORECASE):
        channel_id = 'TVGloboSaoPaulo.br'
    elif re.search("Globo Nordeste",channel,re.IGNORECASE):
        channel_id = 'TVGloboNordeste.br'
    elif re.search("Gloob",channel,re.IGNORECASE):
        channel_id = 'Gloob.br'
    elif re.search("GNT",channel,re.IGNORECASE):
        channel_id = 'GNT.br'
    elif re.search("HBO 2",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBO2Brazil.br'
    elif re.search("HBO Family",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOFamilyBrazil.br'                         
    elif re.search("HBO Mundi",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOMundiBrazil.br'
    elif re.search("HBO Plus",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOPlusBrazil.br'
    elif re.search("HBO Pop",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOPopBrazil.br'
    elif re.search("HBO Signature",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOSignatureBrazil.br'
    elif re.search("HBO Xtreme",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOXtremeBrazil.br'
    elif re.search("HBO",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
        channel_id = 'HBOBrazil.br'
    elif re.search("History 2",channel,re.IGNORECASE):
        channel_id = 'History2Brazil.br'                                                                          
    elif re.search("History",channel,re.IGNORECASE):
        channel_id = 'HistoryBrazil.br'
    elif re.search("Ideal TV",channel,re.IGNORECASE):
        channel_id = 'IdealTV.br'
    elif re.search("Investigação Discovery",channel,re.IGNORECASE) or re.search("Investigacao Discovery",channel,re.IGNORECASE):
        channel_id = 'InvestigationDiscoveryBrazil.br'
    elif re.search("i.Sat",channel,re.IGNORECASE):
        channel_id = 'iSat.br'
    elif re.search("i.Sat",channel,re.IGNORECASE):
        channel_id = 'Lifetime.br'
    elif re.search("Lifetime",channel,re.IGNORECASE):
        channel_id = 'LifetimeBrazil.br'
    elif re.search("Mais GloboSat",channel,re.IGNORECASE) or re.search("Mais na Tela",channel,re.IGNORECASE):
        channel_id = 'MaisnaTela.br'
    elif re.search("Megapix",channel,re.IGNORECASE):
        channel_id = 'Megapix.br'
    elif re.search("MTV Live",channel,re.IGNORECASE):
        channel_id = 'MTVLive.uk'            
    elif re.search("MTV",channel,re.IGNORECASE) and not re.search("US",channel,re.IGNORECASE):
        channel_id = 'MTVBrazil.br'
    elif re.search("Multishow",channel,re.IGNORECASE):
        channel_id = 'Multishow.br'
    elif re.search("Nat Geo Kids",channel,re.IGNORECASE) and not re.search("Nat Geo Wild",channel,re.IGNORECASE) and not re.search("National Geographic",channel,re.IGNORECASE):
        channel_id = 'NatGeoKidsBrazil.br'
    elif re.search("Nat Geo Wild",channel,re.IGNORECASE) or re.search("National Geographic Wild",channel,re.IGNORECASE):
        channel_id = 'NationalGeographicWildBrazil.br'
    elif re.search("National Geographic",channel,re.IGNORECASE):
        channel_id = 'NationalGeographicBrazil.br'
    elif re.search("NBR",channel,re.IGNORECASE):
        channel_id = 'Nbr.br'
    elif re.search("Nickelodeon",channel,re.IGNORECASE) and not re.search("Nick Jr",channel,re.IGNORECASE) and not re.search("Nick Junior",channel,re.IGNORECASE):
        channel_id = 'NickelodeonBrazil.br'
    elif re.search("Nick Jr",channel,re.IGNORECASE):
        channel_id = 'NickJrBrazil.br'
    elif re.search("Novo Tempo",channel,re.IGNORECASE):
        channel_id = 'TVNovoTempoBrasil.br'
    elif re.search("Off",channel,re.IGNORECASE) and not re.search("CNN",channel,re.IGNORECASE):
        channel_id = 'CanalOff.br'
    elif re.search("PlayBoy",channel,re.IGNORECASE):
        channel_id = 'PlayboyTVBrazil.br'
    elif re.search("Paramount",channel,re.IGNORECASE) and not re.search("+",channel,re.IGNORECASE) and not re.search("Plus",channel,re.IGNORECASE):
        channel_id = 'ParamountNetworkBrazil.br'
    elif re.search("Premiere 2",channel,re.IGNORECASE):
        channel_id = 'Premiere2.br'
    elif re.search("Premiere 3",channel,re.IGNORECASE):
        channel_id = 'Premiere3.br'
    elif re.search("Premiere 4",channel,re.IGNORECASE):
        channel_id = 'Premiere4.br'
    elif re.search("Premiere 5",channel,re.IGNORECASE):
        channel_id = 'Premiere5.br'
    elif re.search("Premiere 6",channel,re.IGNORECASE):
        channel_id = 'Premiere6.br'
    elif re.search("Premiere 7",channel,re.IGNORECASE):
        channel_id = 'Premiere7.br'
    elif re.search("Premiere 8",channel,re.IGNORECASE):
        channel_id = 'Premiere8.br'
    elif re.search("Premiere 9",channel,re.IGNORECASE):
        channel_id = 'Premiere9.br'
    elif re.search("Premiere Clubes",channel,re.IGNORECASE):
        channel_id = 'PremiereClubes.br'
    elif re.search("Prime Box",channel,re.IGNORECASE):
        channel_id = 'PrimeBoxBrazil.br'
    elif re.search("Ra Tim Bum",channel,re.IGNORECASE):
        channel_id = 'TVRaTimBum.br'
    elif re.search("Record News",channel,re.IGNORECASE):
        channel_id = 'RecordNews.br'
    elif re.search("Record SP",channel,re.IGNORECASE):
        channel_id = 'RecordTVSaoPaulo.br'
    elif re.search("Record Rio",channel,re.IGNORECASE):
        channel_id = 'RecordTVRio.br'                        
    elif re.search("RecordTV",channel,re.IGNORECASE) or re.search("Record TV",channel,re.IGNORECASE):
        channel_id = 'RecordTV.br'
    elif re.search("Rede Brasil",channel,re.IGNORECASE):
        channel_id = 'RedeBrasil.br'
    elif re.search("Rede TV",channel,re.IGNORECASE) or re.search("RedeTV",channel,re.IGNORECASE):
        channel_id = 'RedeTV.br'
    elif re.search("Rede Vida",channel,re.IGNORECASE):
        channel_id = 'RedeVida.br'
    elif re.search("Rede Amazonica",channel,re.IGNORECASE) or re.search("Rede Amazonas",channel,re.IGNORECASE):
        channel_id = 'RedeAmazonica.br'
    elif re.search("RIT",channel,re.IGNORECASE):
        channel_id = 'RedeInternacionaldeTV.br'          
    elif re.search("SBT",channel,re.IGNORECASE): # ok
        channel_id = 'SBTNacional.br'
    elif re.search("Sexy Hot",channel,re.IGNORECASE) or re.search("SexyHot",channel,re.IGNORECASE):
        channel_id = 'SexyHot.br'
    elif re.search("Sony",channel,re.IGNORECASE):
        channel_id = 'SonyChannelBrazil.br'
    elif re.search("Space",channel,re.IGNORECASE) and not re.search("HBO",channel,re.IGNORECASE):
        channel_id = 'SpaceBrazil.br'
    elif re.search("Sportv 3",channel,re.IGNORECASE):
        channel_id = 'SporTV3.br'  
    elif re.search("Sportv 2",channel,re.IGNORECASE):
        channel_id = 'SporTV2.br'                    
    elif re.search("Sportv",channel,re.IGNORECASE) and not re.search("Sportv 2",channel,re.IGNORECASE) and not re.search("Sportv 3",channel,re.IGNORECASE):
        channel_id = 'SporTV.br'
    elif re.search("Studio Universal",channel,re.IGNORECASE): # ok
        channel_id = 'StudioUniversalBrazil.br'
    elif re.search("Syfy",channel,re.IGNORECASE):
        channel_id = 'SyfyBrazil.br'
    elif re.search("TBS",channel,re.IGNORECASE):
        channel_id = 'TBSBrazil.br'
    elif re.search("TCM",channel,re.IGNORECASE):
        channel_id = 'TCMBrazil.br'
    elif re.search("Telecine Action",channel,re.IGNORECASE):
        channel_id = 'TelecineAction.br'
    elif re.search("Telecine Cult",channel,re.IGNORECASE):
        channel_id = 'TelecineCult.br'
    elif re.search("Telecine Fun",channel,re.IGNORECASE):
        channel_id = 'TelecineFun.br'
    elif re.search("Telecine Pipoca",channel,re.IGNORECASE):
        channel_id = 'TelecinePipoca.br'
    elif re.search("Telecine Premium",channel,re.IGNORECASE):
        channel_id = 'TelecinePremium.br'
    elif re.search("Telecine Touch",channel,re.IGNORECASE):
        channel_id = 'TelecineTouch.br'
    elif re.search("Terra Viva",channel,re.IGNORECASE): # ok
        channel_id = 'TerraViva.br'
    elif re.search("TLC",channel,re.IGNORECASE):
        channel_id = 'TLCBrazil.br'
    elif re.search("TNT Series",channel,re.IGNORECASE) or re.search("TNT Séries",channel,re.IGNORECASE):
        channel_id = 'TNTSeriesBrazil.br'            
    elif re.search("TNT",channel,re.IGNORECASE) and not re.search("TNT Series",channel,re.IGNORECASE) and not re.search("TNT Séries",channel,re.IGNORECASE) and not re.search("HBO",channel,re.IGNORECASE) and not re.search("Novelas",channel,re.IGNORECASE):
        channel_id = 'TNTBrazil.br'
    elif re.search("Tooncast",channel,re.IGNORECASE): # ok
        channel_id = 'Tooncast.us'
    elif re.search("truTV",channel,re.IGNORECASE):
        channel_id = 'truTVBrazil.br'
    elif re.search("TV Aparecida",channel,re.IGNORECASE):
        channel_id = 'TVAparecida.br'
    elif re.search("Tv Brasil",channel,re.IGNORECASE):
        channel_id = 'TVBrasil.br'
    elif re.search("Tv Camara",channel,re.IGNORECASE) or re.search("Tv Câmara",channel,re.IGNORECASE):
        channel_id = 'TVCamara.br'
    elif re.search("Tv Diario Fortaleza",channel,re.IGNORECASE):
        channel_id = 'TVDiario.br'
    elif re.search("Tv Escola",channel,re.IGNORECASE): # ok
        channel_id = 'TVEscola.br'
    elif re.search("TV Gazeta Alagoas",channel,re.IGNORECASE):
        channel_id = 'TVGazetaal.br'
    elif re.search("TV Gazeta",channel,re.IGNORECASE) and not re.search("TV Gazeta Sul",channel,re.IGNORECASE) and not re.search("TV Gazeta Vitoria",channel,re.IGNORECASE):
        channel_id = 'TVGazeta.br'
    elif re.search("Tv Justica",channel,re.IGNORECASE):
        channel_id = 'TVJustica.br'
    elif re.search("TV Liberal Belem",channel,re.IGNORECASE) or re.search("TV Liberal",channel,re.IGNORECASE):
        channel_id = 'TVLiberal.br'
    elif re.search("Tv Senado",channel,re.IGNORECASE):
        channel_id = 'TVSenado.br'
    elif re.search("Tv Verdes Mares",channel,re.IGNORECASE):
        channel_id = 'TVVerdesMares.br'
    elif re.search("VH1",channel,re.IGNORECASE) and not re.search("VH1 Megahits",channel,re.IGNORECASE):
        channel_id = 'VH1Europe.uk'
    elif re.search("VH1 Megahits",channel,re.IGNORECASE):
        channel_id = 'VH1MegaHits.br'
    elif re.search("Viva",channel,re.IGNORECASE):
        channel_id = 'CanalViva.br'
    elif re.search("Warner Channel",channel,re.IGNORECASE) or re.search("Warner",channel,re.IGNORECASE):
        channel_id = 'WarnerChannelBrazil.br'
    elif re.search("WooHoo",channel,re.IGNORECASE):
        channel_id = 'WooHoo.br'
    elif re.search("Zoomoo",channel,re.IGNORECASE):
        channel_id = 'ZooMoo.sg'
    elif re.search("CNN Brasil",channel,re.IGNORECASE) and not re.search("CNN INTERNACIONAL",channel,re.IGNORECASE):
        channel_id = 'CNNBrasil.br'
    elif re.search("Jovem Pan News",channel,re.IGNORECASE):
        channel_id = 'JPNews.br'            
    elif re.search("H2",channel,re.IGNORECASE) and channel.lower().startswith('h2') or re.search("History 2",channel,re.IGNORECASE):
        channel_id = 'History2Brazil.br'
    else:
        channel_id = ''
    return channel_id

def epg_get_program(agora,programas,tipo):
    for item in programas:
        start = str(item.get('start')[:-6]).replace(' ', '').replace('+0000', '')
        stop = str(item.get('stop')[:-6]).replace(' ', '').replace('+0000', '')
        if int(start) <= int(agora) < int(stop) and tipo == 'atual':
            agora = stop
            epg = '\n[COLOR aquamarine][B]' + start[8:-4] + ':' + start[10:-2] + ' ' + item.find('title').text + '[/B][/COLOR]'
            desc = item.find('desc')
            if desc is None:
                sinopse = '\n\nIndisponivel'
            else:
                sinopse = '\n\n'+ desc.text
            desc_epg = sinopse
            return agora,epg,desc_epg
        if int(start) <= int(agora) < int(stop) and tipo == 'proximo':
            epg2 = '\n\n[COLOR aquamarine][B]' + start[8:-4] + ':' + start[10:-2] + ' ' + item.find('title').text + '[/COLOR][/B]'
            desc2 = item.find('desc')
            if desc2 is None:
                sinopse2 = '\n\nIndisponivel'
            else:
                sinopse2 = '\n\n'+ desc2.text
            desc_epg = sinopse2
            return agora,epg2,desc_epg
    return '','',''

def getEPG(root,chan):
    try:
        programas = root.findall("./programme[@channel='"+chan+"']")
        if programas:
            agora = datetime.now()
            agora = agora.strftime("%Y%m%d%H%M%S")
            # atual
            agora, epg1, desc1 = epg_get_program(agora,programas,'atual')
            # proximo
            _, epg2, desc2 = epg_get_program(agora,programas,'proximo')
            epg = epg1
            desc_epg = desc1 + epg2 + desc2
        else:
            epg = '\n[COLOR orange]Epg Indisponível[/COLOR]'
            desc_epg = ''
        return epg, desc_epg
    except:
        epg = '\n[COLOR orange]Epg Indisponível[/COLOR]'
        desc_epg = ''
        return epg, desc_epg 

### CODIGO VIP

def platform():
    try:
        from kodi_six import xbmc

        if xbmc.getCondVisibility('system.platform.android'):
            return 'android'
        elif xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
            return 'linux'
        elif xbmc.getCondVisibility('system.platform.windows'):
            return 'windows'
        elif xbmc.getCondVisibility('system.platform.osx'):
            return 'osx'
        elif xbmc.getCondVisibility('system.platform.atv2'):
            return 'atv2'
        elif xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
            return 'ios'
    except:
        return ''
    
def listar_apks():
    import ntpath
    temp = []
    try:
        apks = req.get(oneplay().vip_downloader).text
        if apks:
            mylist = apks.split("\n")
            if len(mylist) > 0:
                for url in mylist:
                    if '.apk' in url:
                        name = ntpath.basename(url)
                        temp.append((name,url))
                return temp
    except:
        pass
    return False    

def selectapks(items):
    try:
        op = xbmcgui.Dialog().select('SELECIONE UM APK ABAIXO', items)
        return op
    except:
        return 0

def build_itens():
    itens = listar_apks()
    namelist = []
    urllist = []
    if itens:
        for name, url in itens:
            namelist.append(name)
            urllist.append(url)
        select = selectapks(namelist)
        try:
            if select >=0:
                return urllist[select]
        except:
            pass
    return False

def download_py2(url, dest, dp):
    if six.PY3:
        from urllib.request import Request, urlopen  # Python 3
    else:
        from urllib2 import Request, urlopen # Python 2   
    from contextlib import closing
    req = Request(url)  
    req.add_header('User-Agent', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Mobile Safari/537.36')   
    msg = 'Baixando, Aguarde....'
    dp.update(0, msg, '')
    with closing(urlopen(req)) as dl_file:
        with open(dest, 'wb') as out_file:
            out_file.write(dl_file.read())
    notify('Download completo.')

def download_py3(url, dest, dp):
    if six.PY3:
        from urllib.request import build_opener, install_opener, urlretrieve  # Python 3
    else:
        from urllib2 import build_opener, install_opener # Python 2
        from urllib import urlretrieve    
    opener = build_opener()
    opener.addheaders = [('User-agent', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Mobile Safari/537.36')]
    install_opener(opener)        
    urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url, dp):
    try:
        percent = int(min((numblocks*blocksize*100)/filesize, 100))
        currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
        kbps_speed = numblocks * blocksize / (time.time() - start_time)
        if kbps_speed > 0:
            eta = (filesize - numblocks * blocksize) / kbps_speed
        else:
            eta = 0
        kbps_speed = kbps_speed / 1024
        total = float(filesize) / (1024 * 1024)
        if six.PY3:
            msg = '%.02f MB de %.02f MB\n' % (currently_downloaded, total)
            msg += '[COLOR yellow]Speed:[/COLOR] %.02d Kb/s ' % kbps_speed
            msg += '[COLOR yellow]Time left:[/COLOR] %02d:%02d' % divmod(eta, 60)   
            dp.update(percent, msg)
        else:
            mbs = '%.02f MB de %.02f MB' % (currently_downloaded, total)
            e = '[COLOR yellow]Speed:[/COLOR] %.02d Kb/s ' % kbps_speed
            e += '[COLOR yellow]Time left:[/COLOR] %02d:%02d' % divmod(eta, 60)
            dp.update(percent, mbs, e)
    except:
        percent = 100
        dp.update(percent)
    if percent == 100:
        notify('Download completo.')
    elif dp.iscanceled(): 
        dp.close()
        raise notify('Download parado.') 

def download_apk(url, name, dest, dp = None):
    global start_time
    start_time=time.time()
    if not dp:
        dp = xbmcgui.DialogProgress() 
        if six.PY3:
            dp.create('Baixando '+name+'...','Por favor espere...')
        else:
            dp.create('Baixando '+name+'...','Por favor espere...', '', '')
        
    dp.update(0)
    try:
        if six.PY3:
            download_py3(url, dest, dp)
        else:
            download_py2(url, dest, dp)
    except:
        try:
            os.remove(dest)
        except:
            pass
        raise Exception

def apk_manager(url,dest):       
    try:
        import ntpath
        filename = ntpath.basename(url)
        dp = xbmcgui.DialogProgress()
        if six.PY3:
            dp.create('Baixando '+filename+'...','Por favor espere...')
        else:
            dp.create('Baixando '+filename+'...','Por favor espere...', '', '')
        download_apk(url,filename,dest,dp=dp)
        infoDialog('Download completo', iconimage='INFO')
    except:
        infoDialog('Erro ao baixar apk', iconimage='WARNING') 

# MENU VIP
def baixar_apk():
    try:
        if platform() == 'android':
            if six.PY2:
                #q = dialog.yesno(heading="ONEPLAY VIP", line1='DESEJA BAIXAR APK DO ONEPLAY VIP?', nolabel='NÃO', yeslabel='SIM')
                q = dialog.yesno(heading="ONEPLAY VIP", line1=oneplay().vip_dialogo(), nolabel='NÃO', yeslabel='SIM')
            else:
                #q = dialog.yesno(heading="ONEPLAY VIP", message='DESEJA BAIXAR APK DO ONEPLAY VIP?', nolabel='NÃO', yeslabel='SIM')
                q = dialog.yesno(heading="ONEPLAY VIP", message=oneplay().vip_dialogo(), nolabel='NÃO', yeslabel='SIM')
            if q:
                import ntpath
                url = build_itens()
                if url:
                    if url.endswith('.apk'):
                        name = ntpath.basename(url)
                        if not xbmcvfs.exists(oneplay().downloads_android): xbmcvfs.mkdir(oneplay().downloads_android)
                        dest = translate(os.path.join(oneplay().downloads_android,name))
                        try:
                            os.remove(dest)
                        except:
                            pass
                        apk_manager(url,dest)
                        if os.path.isfile(dest):
                            xbmcgui.Dialog().ok(addonname, 'Verifique a pasta download e instale o apk!')

                
        else:
            dialog.ok(addonname, 'SEU DISPOSITIVO NÃO É ANDROID!')
    except:
        pass                                             

def kversion():
    try:
        full_version_info = xbmc.getInfoLabel('System.BuildVersion')
        baseversion = full_version_info.split(".")
        intbase = int(baseversion[0])
        return intbase
    except:
        return 20
    
def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    try:
        """Ask the user for a search string"""
        search_string = None
        k = keyboard(message, heading)
        k.doModal()
        if k.isConfirmed():
            search_string = to_unicode(k.getText())
        return search_string
    except:
        return ''
    
def search():
    try:
        vq = get_search_string(heading='Pesquisa', message="")        
        if ( not vq ): return False
        return vq
    except:
        return ''

def search2():
    try:
        vq = get_search_string(heading='Pesquisa', message="")        
        if ( not vq ): return False
        return quote(vq)
    except:
        return ''        

def item(params, destiny='', folder=True):
    try:
        destiny = destiny.split('/')[1]
    except:
        pass
    try:
        u = f'plugin://{base.split("/")[2]}/{destiny}/{quote_plus(urlencode(params))}'
        liz = listitem(params['name'])
        liz.setArt({'fanart': params.get('fanart', fanart_default), 'thumb': params.get('iconimage', ''), 'icon': "DefaultFolder.png"})
        if kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(params.get('name'))
            info.setMediaType('video')
            info.setPlot(params.get('description', ''))
        else:
            liz.setInfo(type="Video", infoLabels={"Title": params.get('name', ''), 'mediatype': 'video', "Plot": params.get('description', '')})
        if params.get('playable', '') == 'true':
            liz.setProperty('IsPlayable', 'true')
        adddirectory(handle=handle, url=u, listitem=liz, isFolder=folder)
    except:
        pass


def select_tv_server(number,url):
    if number == 1: # aovivo
        url = oneplay().aovivogratis(url)
    elif number == 2: # player
        url = oneplay().resolver_playertv(url)
    elif number == 3:
        url = oneplay().resolver_dazn_server()
    elif number == 4:
        url = oneplay().embedflix_stream(url)        
    return url

def play_item(params):
    try:
        name = params['name']
        stream = params.get('url', '')
        description = params.get('description', '')
        iconimage = params.get('iconimage', '')
        fanart = params.get('fanart', '')
        playable = params.get('playable', '')
        if stream:        
            liz = listitem(name)
            if kversion() > 19:
                info = liz.getVideoInfoTag()
                info.setTitle(name)
                info.setMediaType('video')
                info.setPlot(description)
            else:
                liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
            liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})                     
            liz.setPath(stream)
            if '.mpd' in stream:
                liz.setMimeType('application/xml+dash')
                if six.PY3:
                    liz.setProperty('inputstream', 'inputstream.adaptive')
                else:
                    liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                liz.setProperty('inputstream.adaptive.live_delay', '20')
            if playable == 'true':
                player(int(sys.argv[1]), True, liz)
            else:
                xbmc.Player().play(item=stream, listitem=liz)
        else:
            dialog.notification(addonname, 'Stream indisponivel', xbmcgui.NOTIFICATION_INFO, 3000, sound=False)
    except:
        pass

def proxy_player(param):
    name = unquote_plus(param.get('name', 'ONEPLAY PROXY'))
    playable = unquote_plus(param.get('playable', ''))
    url = unquote_plus(param.get('url', ''))
    number = int(unquote_plus(param.get('number', '5')))
    description = unquote_plus(param.get('description', ''))
    iconimage = unquote_plus(param.get('iconimage', ''))
    fanart = unquote_plus(param.get('fanart', ''))
    url = select_tv_server(number,url)
    try:
        name = name.split('\n')[0]
    except:
        pass    
    if not '.mpd' in url:
        url = 'http://%s:%s/?url=%s'%(str(proxy.HOST_NAME),str(proxy.PORT_NUMBER),quote(url))
    param = {'name': name, 'url': url, 'description': description, 'iconimage': iconimage, 'fanart': fanart, 'playable': playable}
    if not '.mpd' in url:
        proxy.Server().start()
    if '.mpd' in url:
        play_item(param)
    else:
        t1 = threading.Thread(target=play_item, args=(param,))
        t1.start()

def normal_player(param):
    name = unquote_plus(param.get('name', 'ONEPLAY'))
    playable = unquote_plus(param.get('playable', ''))
    url = unquote_plus(param.get('url', ''))
    number = int(unquote_plus(param.get('number', '5')))
    description = unquote_plus(param.get('description', ''))
    iconimage = unquote_plus(param.get('iconimage', ''))
    fanart = unquote_plus(param.get('fanart', ''))
    url = select_tv_server(number,url)
    try:
        name = name.split('\n')[0]
    except:
        pass
    param = {'name': name, 'url': url, 'description': description, 'iconimage': iconimage, 'fanart': fanart, 'playable': playable}
    play_item(param)




def parental_password():
    try:
        folder = 'special://home/userdata/addon_data'
        folder = translate(folder)
        addon_path = os.path.join(folder, addonid)
        if not os.path.exists(addon_path):
            os.mkdir(addon_path)
        xbmc.sleep(7)
        arquivo = os.path.join(addon_path, "password.txt")
        if not os.path.isfile(arquivo):
            password = '0069'
            p_encoded = base64.b64encode(password.encode()).decode('utf-8')
            with open(arquivo,'w') as f:
                f.write(p_encoded)
    except:
        pass

def setnewpassaord():
    try:
        folder = 'special://home/userdata/addon_data'
        folder = translate(folder)
        addon_path = os.path.join(folder, addonid)    
        arquivo = os.path.join(addon_path, "password.txt")
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file.close()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            ps2 = dialog.numeric(0, 'Insira a nova senha:')
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w')
                p_file.write(ps2_b64)
                p_file.close()
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','A Senha foi alterada com sucesso!')
            else:
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Não foi possivel alterar a senha!')
        else:
            dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Senha invalida!, se não alterou utilize a senha padrão')
    except:
        pass

# PROCESSAR GRUPOS SERVIDOR 1
def rodar_grupo(info):
    try:
        grupo, tipo, nome, url, iconimage, fanart, info, epgid = info
        if grupo not in temp_grupo:
            temp_grupo.add(grupo)
            name = '[B]' + grupo + '[/B]'
            item_data = {
                'name': name,
                'iconimage': '',
                'description': '',
                'grupo': grupo
            }
            if adult == 'false' and re.search("Adult",grupo,re.IGNORECASE):
                pass
            else:
                item(item_data, destiny='/tv_servidor1_abrir', folder=True)
    except:
        pass
    
# PROCESSAR CANAIS SERVIDOR 1    
def rodar_grupo2(info):
    try:       
        grupo, tipo, nome, url, iconimage, fanart, info, epgid = info
        if grupo_nome == grupo:
            if epginfo:
                if epgid:
                    try:
                        epg, desc_epg = getEPG(epginfo,epgid)
                        try:
                            nome = nome.decode('utf-8')
                        except:
                            pass                        
                        nome = nome + epg
                        info = desc_epg
                    except:
                        pass
            # EVITAR REFRESH NA SENHA
            if re.search("Adult",grupo_nome,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo_nome,re.IGNORECASE):
                if tipo == 'NORMAL':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '5', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')}, destiny='/play_normal', folder=False)
                elif tipo == 'NORMAL2':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '5', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')}, destiny='/play_normal', folder=False)                
                elif tipo == 'EMBEDFLIX':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '4', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')}, destiny='/play_canais', folder=False)
                elif tipo == 'AOVIVOGRATIS':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '1', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')}, destiny='/play_canais', folder=False)
                elif tipo == 'DAZN1':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '3', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')}, destiny='/play_canais', folder=False)
                elif tipo == 'PLAYERTV':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '2', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')}, destiny='/play_canais', folder=False)                                                                      
            else:
                if tipo == 'NORMAL':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '5', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/play_normal', folder=False)
                elif tipo == 'NORMAL2':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '5', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/play_normal', folder=False)                
                elif tipo == 'EMBEDFLIX':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '4', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/play_canais', folder=False)
                elif tipo == 'AOVIVOGRATIS':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '1', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/play_canais', folder=False)
                elif tipo == 'DAZN1':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '3', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/play_canais', folder=False)
                elif tipo == 'PLAYERTV':
                    item({'name': nome.encode('utf-8', 'ignore'), 'number': '2', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/play_canais', folder=False)
    except:
        pass

def servidor1_categoria():
    global temp_grupo
    temp_grupo = set()        
    try:
        url_canais = oneplay().canais_servidor1
        try:
            src = request_cache(url_canais)
        except:
            src = ''
        if src:
            set_content('movies')
            regex_pattern = r'GRUPO="([^"]*)"\s+TIPO="([^"]*)"\s+NOME="([^"]*)"\s+URL="([^"]*)"\s+ICONIMAGE="([^"]*)"\s+FANART="([^"]*)"\s+INFO="([^"]*)"\s+EPGID="([^"]*)"'
            canais_info = re.findall(regex_pattern, src, re.DOTALL | re.IGNORECASE | re.MULTILINE)
            list(map(rodar_grupo, canais_info))
            end()
            set_view('List')            
    except Exception as e:
        pass

# abrir categoria
def tv_servidor1_abrir_(param):  
    global grupo_nome
    global epginfo   
    set_content('movies')
    grupo_nome = unquote_plus(param.get('grupo', ''))
    try:
        grupo_nome = grupo_nome.decode('utf-8')
    except:
        pass
    try:
        if re.search("Adult",grupo_nome,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo_nome,re.IGNORECASE):
            folder = 'special://home/userdata/addon_data'
            folder = translate(folder)
            addon_path = os.path.join(folder, addonid)
            arquivo = os.path.join(addon_path, "password.txt")
            p_file = open(arquivo,'r+')
            p_file_read = p_file.read()
            p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
            ps = dialog.numeric(0, 'Insira a senha atual:')
            if ps == p_file_b64_decode:
                notify('DIVIRTA-SE!')
                pass
            else:
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Senha invalida!, se não alterou utilize a senha padrão')
                return        
        try:
            url_canais = oneplay().canais_servidor1
            src = request_cache(url_canais)
            regex_pattern = r'GRUPO="([^"]*)"\s+TIPO="([^"]*)"\s+NOME="([^"]*)"\s+URL="([^"]*)"\s+ICONIMAGE="([^"]*)"\s+FANART="([^"]*)"\s+INFO="([^"]*)"\s+EPGID="([^"]*)"'
            canais_info = re.findall(regex_pattern, src, re.DOTALL | re.IGNORECASE | re.MULTILINE)
            if epgEnabled == "true": 
                epginfo = epgParseData()
            else:
                epginfo = False            
            list(map(rodar_grupo2, canais_info))  
            end()
            set_view('List')
        except Exception as e:
            pass
    except:
        pass

def exibir_f4mtester(info):
    nome, url, iconimage, fanart, info, agent = info
    url = base64.b64encode(url.encode()).decode('utf-8')
    agent = base64.b64encode(agent.encode()).decode('utf-8')
    nome = '[B]' + nome + '[/B]'
    item({'name': nome.encode('utf-8', 'ignore'), 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'user': agent}, destiny='/tv_lista', folder=True) 

def servidor2_opcoes():
    set_content('movies')
    try:
        url_canais = oneplay().f4m_servers
        src = request_cache(url_canais)
        pattern = r'NAME="([^"]*)"[\s\S]*?URL="([^"]*)"[\s\S]*?ICONIMAGE="([^"]*)"[\s\S]*?FANART="([^"]*)"[\s\S]*?INFO="([^"]*)"[\s\S]*?AGENT="([^"]*)"'
        canais_info = re.findall(pattern, src, re.DOTALL | re.IGNORECASE | re.MULTILINE)
        list(map(exibir_f4mtester, canais_info))  
        end()
        set_view('List')          
    except Exception as e:
        pass

def grupo_m3u(match):
    # tvg_logo, group_title, channel_name, channel_link = match
    # tvg_logo = tvg_logo.strip() if tvg_logo else ""
    # group_title = group_title.strip() if group_title else ""
    try:
        groups_re, channel_name, channel_link, _ = match
    except:
        groups_re, channel_name, channel_link = match
    try:
        tvg_logo = re.findall(r'tvg-logo="(.*?)"', groups_re, re.IGNORECASE)[0]
        tvg_logo = tvg_logo.strip()
    except:
        tvg_logo = ''
    try:
        group_title = re.findall(r'group-title="(.*?)"', groups_re, re.IGNORECASE)[0]
        group_title = group_title.strip()
        try:
            group_title = group_title.decode('utf-8')
        except:
            pass
    except:
        group_title = ''
    if group_title:
        if group_title not in temp_grupo:
            temp_grupo.add(group_title)
            name = '[B]' + group_title + '[/B]'
            item_data = {
                'name': name,
                'url': url,
                'user': agent,
                'iconimage': '',
                'description': '',
                'grupo': group_title
            } 
            if adult == 'false' and re.search("Adult",group_title,re.IGNORECASE):
                pass
            else:
                item(item_data, destiny='/exibir_grupo_lista', folder=True)

def grupo_m3u2(match):
    # tvg_logo, group_title, channel_name, channel_link = match
    # tvg_logo = tvg_logo.strip() if tvg_logo else ""
    # group_title = group_title.strip() if group_title else ""
    try:
        groups_re, channel_name, channel_link, _ = match
    except:
        groups_re, channel_name, channel_link = match
    try:
        tvg_logo = re.findall(r'tvg-logo="(.*?)"', groups_re, re.IGNORECASE)[0]
        tvg_logo = tvg_logo.strip()
    except:
        tvg_logo = ''
    try:
        group_title = re.findall(r'group-title="(.*?)"', groups_re, re.IGNORECASE)[0]
        group_title = group_title.strip()
        try:
            group_title = group_title.decode('utf-8')
        except:
            pass
    except:
        group_title = ''
    if channel_link:
        channel_link = channel_link.strip()
    if group_title == grupo:
        try:
            channel_name = channel_name.decode('utf-8')
        except:
            pass
        channel_name = channel_name.replace('&amp;', '&')
        if epginfo:
            try:
                epg, desc_epg = getEPG(epginfo,getID_EPG(channel_name))
                name = '[B]' + channel_name + '[/B]' + epg
                #name = channel_name + epg
                info = desc_epg
            except:
                name = '[B]' + channel_name + '[/B]'
                info = ''
        else:
            name = '[B]' + channel_name + '[/B]'
            info = ''
        if '.mp4' in channel_link:
            item_data = {
            'name': name.encode('utf-8', 'ignore'),
            'url': channel_link,
            'iconimage': tvg_logo,
            'description': info.encode('utf-8', 'ignore'),
            'playable': 'true'
            }
            item(item_data, destiny='/player_normal', folder=False) 
        else: 
            item_data = {
            'name': name.encode('utf-8', 'ignore'),
            'url': channel_link,
            'iconimage': tvg_logo,
            'description': info.encode('utf-8', 'ignore')
            } 
            item(item_data, destiny='/play_canais', folder=False)                      

def exibir_lista(param):
    global temp_grupo
    global url
    global agent
    url = unquote_plus(param.get('url', ''))
    agent = unquote_plus(param.get('user', ''))
    try:
        url = base64.b64decode(url).decode('utf-8')
    except:
        pass
    try:
        agent = base64.b64decode(agent).decode('utf-8')
    except:
        pass        
    try:
        src = request_cache(url,headers={'User-Agent': agent})
        set_content('movies')
        # Encontrar a lista M3U dentro do texto
        m3u_match = re.search(r'#EXTM3U.*', src, re.DOTALL)
        if m3u_match:
            m3u_content = m3u_match.group()
        else:
            # Se a lista M3U não for encontrada, encerrar a execução
            return
        #pattern = r'#EXTINF:(?:-?\d+)?\s.*?(?:tvg-logo="([^"]*)")?.*?(?:group-title="([^"]*)")?,(.*?)\n(.*?)\n'
        #pattern = r'#EXTINF:(?:-?\d+)?\s.*?(?:tvg-logo="(.*?)"?\s*)?(?:group-title="(.*?)"?\s*)?(?:(.*?)\n(.*?)\n)?'
        #pattern = r'#EXTINF:(.*?),(.*?)\n(.*?)\n'
        pattern = r'#EXTINF:(.*?),(.*?)(?:\n(.*?))?(\n|$)'
        matches = re.findall(pattern, m3u_content, re.IGNORECASE)
        temp_grupo = set()
        url = base64.b64encode(url.encode()).decode('utf-8')
        agent = base64.b64encode(agent.encode()).decode('utf-8')                 
        list(map(grupo_m3u, matches))
        end()
        set_view('List')
    except Exception as e:
        pass

def exibir_grupo_m3u(param):
    global grupo
    global epginfo  
    url = unquote_plus(param.get('url', ''))
    agent = unquote_plus(param.get('user', ''))
    grupo = unquote_plus(param.get('grupo', ''))
    try:
        grupo  = grupo.decode('utf-8')
    except:
        pass
    try:
        url = base64.b64decode(url).decode('utf-8')
    except:
        pass
    try:
        agent = base64.b64decode(agent).decode('utf-8')
    except:
        pass
    if re.search("Adult",grupo,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo,re.IGNORECASE):
        folder = 'special://home/userdata/addon_data'
        folder = translate(folder)
        addon_path = os.path.join(folder, addonid)
        arquivo = os.path.join(addon_path, "password.txt")
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            notify('DIVIRTA-SE!')
            pass
        else:
            dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Senha invalida!, se não alterou utilize a senha padrão')
            return
    try:
        src = request_cache(url,headers={'User-Agent': agent})
        set_content('movies')
        # Encontrar a lista M3U dentro do texto
        m3u_match = re.search(r'#EXTM3U.*', src, re.DOTALL)
        if m3u_match:
            m3u_content = m3u_match.group()
        else:
            # Se a lista M3U não for encontrada, encerrar a execução
            return
        #pattern = r'#EXTINF:(?:-?\d+)?\s.*?(?:tvg-logo="([^"]*)")?.*?(?:group-title="([^"]*)")?,(.*?)\n(.*?)\n'
        #pattern = r'#EXTINF:(.*?),(.*?)\n(.*?)'
        #pattern = r'#EXTINF:(.*?),(.*?)\n(.*?)\n'
        pattern = r'#EXTINF:(.*?),(.*?)(?:\n(.*?))?(\n|$)'
        matches = re.findall(pattern, m3u_content, re.IGNORECASE) 
        if epgEnabled == "true": 
            epginfo = epgParseData()
        else:
            epginfo = False                             
        list(map(grupo_m3u2, matches))
        end()
        set_view('List')
    except Exception as e:
        pass

try:
    class Donate(xbmcgui.WindowDialog):
        def __init__(self):
            try:
                self.image = xbmcgui.ControlImage(440, 128, 400, 400, icons('qrcode'))
                self.text = xbmcgui.ControlLabel(x=150,y=570,width=1100,height=25,label='[B][COLOR yellow]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/COLOR][/B]',textColor='yellow')
                self.text2 = xbmcgui.ControlLabel(x=495,y=600,width=1000,height=25,label='[B][COLOR yellow]PRESSIONE VOLTAR PARA SAIR[/COLOR][/B]',textColor='yellow')
                self.addControl(self.image)
                self.addControl(self.text)
                self.addControl(self.text2)
            except:
                pass
except:
    pass

def donate_question():
    try:
        if six.PY2:
            q = dialog.yesno(heading=addonname, line1='Deseja fazer doação ao desenvolvedor?', nolabel='Não', yeslabel='Sim')
        else:
            q = dialog.yesno(heading=addonname, message='Deseja fazer doação ao desenvolvedor?', nolabel='Não', yeslabel='Sim')
        if q:
            dialog.ok('AVISO','A DOAÇÃO É UMA AJUDA AO DESENVOLVEDOR E NÃO DA DIREITO AO VIP!')
            dialog_donate = Donate()
            dialog_donate.doModal()
    except:
        pass      


def route(r):
    try:
        route_decorator = r.split('/')[1] # function name from route
        plugin_route = base.split('/')[3:] # command from sys
        route_sys = plugin_route[0] # function name from sys
        def decorator(f):
            params = {}
            try:
                param_root = plugin_route[1] # params from sys
                param_root = unquote_plus(param_root).split('&')
                for command in param_root:
                    if '=' in command:
                        split_command = command.split('=')
                        key = split_command[0]
                        value = split_command[1]
                        params[key] = value
                    else:
                        params[command] = ''
            except:
                pass
            if not route_decorator and not route_sys:
                try:
                    f(params)
                except:
                    f()
            elif route_decorator == route_sys:
                try:
                    f(params)
                except:
                    f()
        return decorator
    except:
        def decorator(f):
            return f
        return decorator