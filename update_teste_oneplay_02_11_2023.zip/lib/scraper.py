# -*- coding: utf-8 -*-
import six
try:
    from lib import jsunpack
except:
    import jsunpack
from fasthttp import req
from bs4 import BeautifulSoup
import re
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
import random
import time
import base64
if six.PY3:
    from urllib.request import build_opener, install_opener, Request, urlopen, URLError, urlretrieve  # Python 3
else:
    from urllib2 import build_opener, install_opener, Request, urlopen, URLError # Python 2
    from urllib import urlretrieve

class Tube:
    def __init__(self,url):
        self.api = 'https://www.youtube.com/youtubei/v1/player'
        self.key = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8'
        self.length = 0
        self.title = ''
        self.author = ''
        self.thumbnail = ''
        self.url = ''
        self.headers = {'User-Agent': 'com.google.android.apps.youtube.music/', 'Accept-Language': 'en-US,en'}
        self.result = self.scrape_api(self.get_id(url))                     
        
    def get_id(self,url):
        video_id = ''
        video_id_match = re.search(r'v=([A-Za-z0-9_-]+)', url)
        if video_id_match:
            id_ = video_id_match.group(1)
            try:
                id_ = id_.split("&")[0]
            except:
                pass
            video_id = id_
        return video_id
    
    def pick_source(self,sources):
        quality_max = 0
        url_max = ''
        for quality, url in sources:
            quality = quality.replace('p', '')
            if int(quality) > quality_max:
                quality_max = int(quality)
                url_max = url
        return url_max               
    
    def scrape_api(self,video_id):
        #api = f'{self.api}?videoId={video_id}&key={self.key}&contentCheckOk=True&racyCheckOk=True'
        api = '%s?videoId=%s&key=%s&contentCheckOk=True&racyCheckOk=True'%(self.api,video_id,self.key)
        json_music = {
            "context": {
                "client": {
                    "androidSdkVersion": 30,
                    "clientName": "ANDROID_MUSIC",
                    "clientVersion": "5.16.51"
                }
            }
        }
        json_normal = {
            "context": {
                "client": {
                    "androidSdkVersion": 30,
                    "clientName": "ANDROID_EMBEDDED_PLAYER",
                    "clientScreen": "EMBED",
                    "clientVersion": "17.31.35"
                }
            }
        }
        result = {}
        #response_music = requests.post(api, json=json_music)
        response_music = req.post(api,json=json_music, headers=self.headers, replace_headers=True)
        if response_music.status_code == 200:
            r = response_music.json()
            details = r['videoDetails']
            self.length = int(details['lengthSeconds'])
            self.title = details['title']
            self.author = details['author']
            thumb = details['thumbnail']['thumbnails']
            try:
                select_thumb = [image['url'] for image in thumb][-1]
                self.thumbnail = select_thumb
            except:
                pass
            ok_music = r.get("streamingData", False)
            if ok_music:
                result = r
        if not result:
            #response_music = requests.post(api, json=json_normal)
            response_music = req.post(api, json=json_normal, headers=self.headers, replace_headers=True)
            if response_music.status_code == 200:
                r = response_music.json()
                ok_normal = r.get("streamingData", False)
                if ok_normal:
                    result = r
        if result:
            try:
                videos = result['streamingData']['formats']
                sources = [(v['qualityLabel'], v['url']) for v in videos]
                self.url = self.pick_source(sources)
            except:
                pass

        return result
    
class oneplay:
    def __init__(self):
        self.sitefilmes = 'https://netcine.rs'
        self.site_novelas = 'https://novelasflixbr.com/'
        self.site_anime = 'https://meuanime.io'
        self.site_desenho = 'https://animesgames.cc/desenhos'
        self.site_futebol = 'https://futebolplayhd.com/tvonline/'
        self.referer_futebol = 'https://futebolplayhd.com/'
        self.desc_addon = 'https://gist.github.com/zoreu/ed4f3d92f995bfcc01891a2e94404ce8/raw/descricao_oneplay.txt'
        self.link_update = 'https://gist.github.com/zoreu/5600010d2b346983e353bab147932a73/raw/update_oneplay2.txt'
        self.desc_vip = 'https://oneplayhd.com/download/vip/info_oneplay.txt'
        self.dialogo_vip = 'https://oneplayhd.com/download/vip/dial_oneplay.txt'
        self.vip_downloader = 'https://oneplayhd.com/download/vip/apks_oneplay.txt'
        self.downloads_android = '/storage/emulated/0/download'
        self.canais_servidor1 = 'https://gist.github.com/zoreu/b1912aa40daaec0eabf1a74c51e310a0/raw/canais_servidor1.txt'
        self.f4m_servers = 'https://gist.github.com/zoreu/cfac084dfc41cb204496254c5b3c49a3/raw/f4m_servers.txt'
        self.epg_url_version = 'https://github.com/zoreu/epgoneplay/raw/output/update.txt'
        self.url_epg = 'https://github.com/zoreu/epgoneplay/raw/output/epg.xml'
        self.nomecontador = 'Addon_OnePlay_(2023)'
        self.paginacontador = 'https://github.com/OnePlayHD/OneRepo/'
        self.keycontador = 'oneplay'        
        self.IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
        self.FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
        self.OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36 OPR/67.0.3575.97'
        self.IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
        self.IPAD_USER_AGENT = 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10'
        self.ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36'
        self.EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363'
        self.CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'        
        self.SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
        self._USER_AGENTS = [self.FF_USER_AGENT, self.OPERA_USER_AGENT, self.EDGE_USER_AGENT, self.CHROME_USER_AGENT, self.SAFARI_USER_AGENT]        
        self.headers = {'User-Agent': self.CHROME_USER_AGENT,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,es;q=0.6',
                    'sec-ch-ua': '"Chromium";v="115", "Not A(Brand";v="99", "Google Chrome";v="115"',
                    'sec-ch-ua-mobile': '?1',
                    'sec-ch-ua-platform': '"Android"',
                    'Sec-Fetch-Dest': 'document',
                    'Sec-Fetch-Mode': 'navigate',
                    'Sec-Fetch-Site': 'none',
                    'Sec-Fetch-User': '?1',
                    'Upgrade-Insecure-Requests': '1'   
                        }
        self.itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
    '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
    '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
    '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
    '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
    '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
    '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
    '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
    '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
    '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}
        
    def pick_source(self,sources):
        return sources[0][1]

    def __key(self, item):
        try:
            return int(re.search(r'(\d+)', item[0]).group(1))
        except:
            return 0 

    def _parse_gdocs(self, html):
        urls = []
        if 'error' in html:
            reason = unquote_plus(re.findall('reason=([^&]+)', html)[0])
            raise ValueError(reason)
        value = unquote(re.findall('fmt_stream_map=([^&]+)', html)[0])
        items = value.split(',')
        for item in items:
            _source_itag, source_url = item.split('|')
            if isinstance(source_url, six.text_type) and six.PY2:  # @big change
                source_url = source_url.decode('unicode_escape').encode('utf-8')
            quality = self.itag_map.get(_source_itag, 'Unknown Quality [%s]' % _source_itag)
            source_url = unquote(source_url)
            urls.append((quality, source_url))
        return urls

    def resolve_url(self,link):
        sources = []
        cookies = None
        referer = ''
        if 'drive.google.com' in link:
            referer = 'https://youtube.googleapis.com/'
            link = re.findall('/file/.*?/([^/]+)', link)[0]
            link = 'https://drive.google.com/get_video_info?docid=' + link
            #response = requests.get(link,headers=cls.headers)
            response = req.get(link,headers=self.headers,replace_headers=True)
            cookies = response.cookies
            sources = self._parse_gdocs(response.text)
        elif 'blogger.com/video.g?token=' in link:
            referer =  'https://www.youtube.com/'
            #response = requests.get(link,headers=cls.headers)
            response = req.get(link,headers=self.headers,replace_headers=True)
            cookie = response.cookies
            source = re.findall(r'play_url.+?"(.+?)","format_id":(.+?)}', response.text)
            if source:
                sources = [(self.itag_map.get(quality, 'Unknown Quality [%s]' % quality), stream.decode('unicode-escape') if six.PY2 else stream) for stream, quality in source]
        return sources, cookies, referer

    def select_video(self,sources):
        if sources:
            sources.sort(key=self.__key, reverse=True)
            video = self.pick_source(sources)
        else:
            video = ''
        return video

    def find_video(self,link):
        try:
            sources, cookies, referer = self.resolve_url(link)
            video = self.select_video(sources)
        except:
            cookies = None
            referer = None
            video = ''
        if video:
            if cookies:
                cookies_str = ";".join(["%s=%s"%(key,value) for key, value in cookies.items()])
                if referer:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Cookie=' + quote(cookies_str) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Cookie=' + quote(cookies_str)
            else:
                if referer:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT)
        return video                                  
    
    def rand_ua(self):
        RAND_UA = random.choice(self._USER_AGENTS)
        return RAND_UA

    def descricao_addon(self):
        desc = ''
        try:
            r = req.get(self.desc_addon)
            desc += r.text
        except:
            pass
        return desc
    
    def vip_descricao(self):
        desc = ''
        try:
            r = req.get(self.desc_vip)
            desc += r.text
        except:
            pass
        return desc
    
    def vip_dialogo(self):
        desc = ''
        try:
            r = req.get(self.dialogo_vip)
            desc += r.text
        except:
            pass
        return desc    
    
    def get_proxy(self):
        proxy = []      
        try:
            r = req.get('https://www.sslproxies.org/',verify=False)
            html = r.text
            soup = BeautifulSoup(html, 'html.parser')
            tr = soup.find('tbody').find_all('tr')
            for t in tr:
                td_tags = t.find_all('td')
                ip_address = td_tags[0].text
                port_number = td_tags[1].text
                code = td_tags[2].text
                country = td_tags[3].text
                anonymity = td_tags[4].text
                google = td_tags[5].text
                https = td_tags[6].text
                checked = td_tags[7].text
                if https == 'yes' and anonymity == 'anonymous':
                    string_p = 'https://' + str(ip_address) + ':' + str(port_number)
                    proxy.append(string_p)
        except:
            pass
        if proxy:
            return random.choice(proxy)
        else:
            p = ''
            return p       
    
    def append_headers(self,headers):
        return '|%s' % '&'.join(['%s=%s' % (key, quote_plus(headers[key])) for key in headers]) 

    def get_ip(self):
        ip = ''
        # try:
        #     r = req.get('https://api4.my-ip.io/ip.jsonp?format=jsonp&callback=getIP')
        #     src = r.text
        #     ip += re.findall(r'getIP\({"success": true, "ip": "(.*?)"', src)[0]
        # except:
        #     pass
        try:
            r = req.get('https://api.ipify.org/?format=json')
            src = r.json()
            ip += src['ip']
        except:
            pass
        return ip

    def soup(self,html):
        soup = BeautifulSoup(html,'html.parser')
        return soup

    def embedflix_stream(self,myid):
        stream = ''
        headers = self.headers
        homepage = 'https://embedflix.net/tv/' + myid
        referer = 'https://embedflix.net/'
        origin = 'https://embedflix.net'
        url = 'https://embedflix.net/api'
        try:
            r = req.get(homepage,headers=headers,replace_headers=True)
            src = r.text
            find_video_id = re.findall(r'video_id = (.*?);', src)
            find_action = re.findall(r"data\s*:\s*\{[\s\S]*?action\s*:\s*'([^']*)'", src)
            #find_source = re.findall(r"source:\s+`([^`]+)`", src)
            find_source = re.findall(r"\$\{msg\.data\.video_url\}(\S+)`", src)
            #if find_video_id and find_action and find_source:
            if find_video_id and find_action:
                video_id = find_video_id[0]
                action = find_action[0]
                #source = find_source[0]
            else:
                return
        except:
            return            
        ip = self.get_ip()
        headers.update({'Origin': origin, 'Referer': referer})
        #data_post = {'action': 'getPlayer', 'client_ip': ip, 'video_id': myid}
        data_post = {'action': action, 'client_ip': ip, 'video_id': video_id}        
        try:
            r = req.post(url,headers=headers,data=data_post,replace_headers=True)
            src = r.json()
            if src:
                data = [k for k in src.keys()][-1]
                data = src.get(data, '')
                if data:
                    video_url = [k for k in data.keys()][1]
                    video_url = data.get(video_url, '')
                    url_signature = [k for k in data.keys()][2]
                    url_signature = data.get(url_signature, '')
                    if video_url and url_signature:
                        stream = video_url + '?wmsAuthSign=' + url_signature + self.append_headers(headers)
                    elif video_url and find_source:
                        stream = video_url + find_source[0] + self.append_headers(headers)
        except:
            pass
        return stream

    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data

    def get_host(self,url):
        url_parsed = urlparse(url)
        host = '%s://%s'%(url_parsed.scheme,url_parsed.netloc)
        return host

    def decode_sequence(self,match):
        return chr(int(match.group(1)))

   # aovivo
    def aovivogratis(self,channel):
        user_agent_fasthttp = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661'
        stream = ''
        try:
            url = 'https://player.aovivotv.xyz/channels/%s'%channel
            referer = 'https://www.tibiadown.com/'
            origin = self.get_host(url)
            referer2 = origin + '/'
            ct = 0
            check = False
            while True:
                ct += 1
                time.sleep(4)
                r = req.get(url,headers={'Referer': referer})
                if r.status_code == 200:
                    src = r.text
                    if src:
                        count = 0
                        while True:
                            count += 1
                            try:
                                unpack = self.get_packed_data(src)
                                media = re.findall(r'const\s+media\s*=\s*\'(.*?)\';', unpack)
                                items = media[0].split('+')
                                src = [chr(int(re.findall(r'\d+', x)[0])) if 'String.' in x else x.replace("'", "") for x in items]
                                src = ''.join(src)
                                src = src.encode("utf-8").decode("unicode-escape")
                                src = unquote(src)
                                try:
                                    src.decode('utf-8')
                                except:
                                    pass
                                src = 'https:' + src
                                stream = src + '|User-Agent=' + quote(user_agent_fasthttp) + '&Referer=' + quote(referer2) + '&Origin=' + quote(origin)
                                check = True                 
                                break
                            except:
                                pass
                            if count == 4:
                                break
                        # codificacao anterior
                        #items = re.findall(r'src:\s*(.+?),type', unpack)[0].split('+')
                        #print(items)
                        #src = [chr(int(re.findall(r'\d+', x)[0])) if 'String.' in x else x.replace("'", "") for x in items]
                        #src = ''.join(src)
                        # src = src.encode("utf-8").decode("unicode-escape")
                        # src = 'https:' + src
                        # stream = src + '|User-Agent=' + user_agent_fasthttp + '&Referer=' + referer2 + '&Origin=' + origin
                # else:
                #     print('acesso negado')
                if check == True:
                    break
                elif ct == 4:
                    break

        except:
            pass
        return stream

    def last_url(self,url,headers):
        if six.PY3:
            r = Request(url, method='HEAD', headers=headers)
        else:
            r = Request(url,headers=headers)
            r.get_method = lambda : 'HEAD'
        try:
            response = urlopen(r)
            if six.PY3:
                final_url = response.url
            else:
                final_url = response.geturl()
        except:
            final_url = url
        return final_url

    # streamtape
    def resolve_streamtape(self,url):
        correct_url = url.replace('/v/', '/e/')
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme
        host = parsed_uri.netloc
        referer = '%s://%s/'%(protocol,host)
        headers = self.headers
        headers.update({'Referer': referer})
        r = req.get(correct_url,headers=headers,replace_headers=True)
        data = r.text
        link_part1_re = re.compile('<div.+?style="display:none;">(.*?)&token=.+?</div>').findall(data)
        link_part2_re = re.compile("&token=(.*?)'").findall(data)
        if link_part1_re and link_part2_re:
            part1 = link_part1_re[0]
            part2 = link_part2_re[-1]
            part1 = part1.replace(' ', '')
            if 'streamtape' in part1:
                try:
                    part1 = part1.split('streamtape')[1]
                    final = 'streamtape' + part1 + '&token=' + part2
                    stream = 'https://' + final + '&stream=1'
                    #r2 = req.get(stream,headers=headers,replace_headers=True)
                    #link = r2.url + self.append_headers(headers)
                    link = self.last_url(stream,headers=headers) + self.append_headers(headers)
                except:
                    link = False
            elif 'get_video' in part1:
                try:
                    part1_1 = part1.split('get_video')[0]
                    part1_2 = part1.split('get_video')[1]
                    part1_1 = part1_1.replace('/', '')
                    part1 = part1_1 + '/get_video' + part1_2
                    final = part1 + '&token=' + part2
                    stream = 'https://' + final + '&stream=1'
                    # r2 = req.get(stream,headers=headers,replace_headers=True)
                    # link = r2.url + self.append_headers(headers)
                    link = self.last_url(stream,headers=headers) + self.append_headers(headers)
                except:
                    link = False
        else:
            link = False
        return link

    # CDN
    def resolve_warezcdn(self,url):
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme
        host = parsed_uri.netloc
        referer = '%s://%s'%(protocol,host)
        headers = self.headers
        sub = ''
        try:
            _id = url.split("id=")[1]
            try:
                _id = _id.split('&')[0]
            except:
                pass
        except:
            _id = ''
        if _id:
            try:
                headers.update({'Referer': referer})
                r = req.get(url,headers=headers,replace_headers=True)
                src = r.text
                key = re.findall('allowanceKey = "(.+?)"', src,re.DOTALL|re.MULTILINE|re.IGNORECASE)[0]
                cdn = re.findall('cdnListing = \[(.+?)\]', src,re.DOTALL|re.MULTILINE|re.IGNORECASE)[0].split(',')
                cdn = random.choice(cdn)
                param = {'getVideo': _id, 'key': key}
                headers.update({'Referer': url})
                r2 = req.post('https://warezcdn.com/player/functions.php', headers=headers, replace_headers=True, data=param)
                src = r2.json()
                code = src['id']
                sub = src.get('substatus',False)
                if sub == True:
                    sub = src.get('sublink','')
                    sub = sub + '|User-Agent=' + headers['User-Agent'] + '&Referer=' + url
                else:
                    sub = ''
                base = base64.b64decode(code).decode('utf-8')[::-1]
                base = base[:+9] + base[13] + base[+10:+13][::-1] + base[9]
                url_player = 'https://cloclo%s.cloud.mail.ru/weblink/view//%s'%(cdn,base)
                referer2 = url_player
                headers.update({'Referer': referer2})
                #lasturl = req.get(url_player, headers=headers,replace_headers=True).url
                lasturl = self.last_url(url_player,headers)
                stream = lasturl + '|User-Agent=' + headers['User-Agent'] + '&Referer=https://warezcdn.com/'
            except:
                stream = ''
                sub = ''
        return stream, sub

    def resolve_mixdrop(self,url):
        url = url.replace('.club', '.co')
        try:
            url = url.split('?')[0]
        except:
            pass
        stream = ''
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme
        host = parsed_uri.netloc
        # if host.endswith('.club'):
        #     host = host.replace('.club', '.co')
        rurl = 'https://%s/'%host     
        headers = {'Origin': rurl[:-1],'Referer': rurl, 'User-Agent': self.rand_ua()}
        try:
            html = req.get(url,headers=headers,replace_headers=True).text
            r = re.search(r'location\s*=\s*"([^"]+)', html)
            if r:
                url = 'https://%s%s'%(host,r.group(1))
                html = req.get(url,headers=headers,replace_headers=True).text
            if '(p,a,c,k,e,d)' in html:
                html = self.get_packed_data(html)
            r = re.search(r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)', html)
            if r:
                surl = r.group(1)
                if surl.startswith('//'):
                    surl = 'https:' + surl
                #headers.pop('Origin')
                headers.update({'Referer': url})
                stream = surl + self.append_headers(headers)
        except:
            pass
        return stream

    def resolve_netcine(self,url):
        stream = ''
        headers = self.headers
        headers.update({'Cookie': 'XCRF%3DXCRF', 'Referer': 'https://netcine.vc/'})
        try:
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            regex_pattern = r'<source[^>]*\s+src="([^"]+)"'
            alto = []
            baixo = []
            matches = re.findall(regex_pattern, src)
            for match in matches:
                if 'ALTO' in match:
                    alto.append(match)
                if 'alto' in match:
                    alto.append(match)
                if 'BAIXO' in match:
                    baixo.append(match)
                if 'baixo' in match:
                    baixo.append(match)
            if alto:
                stream = alto[-1] + '|User-Agent=' + headers['User-Agent'] + '&Referer=' + headers['Referer'] + '&Cookie=' + headers['Cookie']
            elif baixo:
                stream = baixo[-1] + '|User-Agent=' + headers['User-Agent'] + '&Referer=' + headers['Referer'] + '&Cookie=' + headers['Cookie']   
        except:
            pass
        return stream

    # gofilmes
    def resolve_gofilmes(self,url):
        stream = ''
        headers = self.headers
        headers.update({'Origin': 'https://gofilmes.me','Referer': 'https://gofilmes.me/'})
        try:
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            match1 = re.findall(r'"g"\s*:\s*"(https://[^"]+)"', src)
            match2 = re.findall(r'<source.+?src="(.*?)"', src)
            #match3 = re.findall(r'const id = "(.*?)";', src,re.DOTALL|re.MULTILINE)
            if match1:
                stream = match1[0] + '|User-Agent=' + headers['User-Agent'] + '&Origin=' + headers['Origin'] + '&Referer=' + headers['Referer']
            elif match2:
                stream = match2[0] + '|User-Agent=' + headers['User-Agent'] + '&Origin=' + headers['Origin'] + '&Referer=' + headers['Referer']
        except:
            pass
        return stream

    def resolve_youtube(self,url):
        stream = ''
        try:
            api = Tube(url)
            stream += api.url
        except:
            pass
        return stream

    # RESOLVE
    def resolverurl(self,url):
        stream = ''
        sub = ''
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        domain = domain.replace('www.', '').replace('ww3.', '').replace('ww4.', '')
        if domain in ['streamtape.com', 'strtape.cloud', 'streamtape.net', 'streamta.pe', 'streamtape.site',
               'strcloud.link', 'strtpe.link', 'streamtape.cc', 'scloud.online', 'stape.fun',
               'streamadblockplus.com', 'shavetape.cash', 'streamtape.to', 'streamta.site',
               'streamadblocker.xyz', 'tapewithadblock.org', 'adblocktape.wiki']:
            stream = self.resolve_streamtape(url)
        elif domain in ['warezcdn.com']:
            stream, sub = self.resolve_warezcdn(url)
        elif domain in ['mixdrop.co', 'mixdrop.to', 'mixdrop.sx', 'mixdrop.bz', 'mixdrop.ch',
               'mixdrp.co', 'mixdrp.to', 'mixdrop.gl', 'mixdrop.club', 'mixdroop.bz']:
            stream = self.resolve_mixdrop(url)
        # elif 'netcine' in domain:
        #     stream = self.resolve_netcine(url)
        elif domain in ['gofilmes.me']:
            stream = self.resolve_gofilmes(url)
        elif 'youtube' in domain:
            stream = self.resolve_youtube(url)
        if not stream:
            stream = ''
        # if not stream:
        #     stream = url
        return stream, sub

    def contador(self):
        try:
            url = 'https://whos.amung.us/pingjs/?k=%s&t=%s&c=s&x=%s&y=&a=0&d=0.74&v=27&r=1230'%(self.keycontador,self.nomecontador,quote(self.paginacontador))
            req.get(url)
        except:
            pass

    def resolver_dazn_server(self):
        stream = ''
        try:
            headers = self.headers
            headers.update({'Referer': 'https://onlinetvhd.net/canal/dazn/1/index.php'})
            r = req.get('https://playertv.net/tv.php?c=dazn&&&https://onlinetvhd.net/canal/dazn/1/index.php&clang=canal', headers=headers,replace_headers=True)
            src = r.text
            stream = re.findall("file: '(.*?)'", src)
            stream = stream[0] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer='+ quote('https://playertv.net/tv.php?c=dazn&&&https://onlinetvhd.net/canal/dazn/1/index.php&clang=canal')
        except:
            pass
        return stream

    def resolver_playertv(self,channel):
        url = 'https://playertv.net/tv.php?c=' + channel
        referer = 'http://detran-br.com/canal.php?op=' + channel
        stream = ''
        PROXY = False
        try:
            headers = self.headers
            headers.update({'Referer': referer})
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            stream = re.findall("file: '(.*?)'", src)
            stream = stream[0] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(url)
        except:
            pass
        return stream 

    def warezcdn_servers(self,imdb,season=False,episode=False):
        servers = []
        referer = 'https://embed.warezcdn.com/'
        if season and episode:
            url = 'https://embed.warezcdn.com/serie/%s/%s/%s'%(str(imdb),str(season),str(episode))
            data = req.get(url,headers={'Referer': referer}).text
            audio_id = re.compile('<div class="item" data-load-episode-content="(.*?)">.+?<img class="img" src="(.*?)" loading="lazy">.+?<div class="name">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
            if audio_id:
                audio = ''
                for id, img, name in audio_id:
                    if str(episode) in name:
                        audio += str(id)
                        break
                if audio:
                    data2 = req.post('https://embed.warezcdn.net/serieAjax.php', headers={'Referer': referer}, data={'getAudios': audio}).json()
                    lang = []
                    languages = data2.get('list', '')
                    if languages:
                        for key in languages:
                            d = languages[key]
                            _id = d['id']
                            audio = d['audio']
                            mixdrop = d.get('mixdropStatus', '')
                            fembed = d.get('fembedStatus', '')
                            streamtape = d.get('streamtapeStatus', '')
                            warezcdn = d.get('warezcdnStatus', '')
                            lang.append((_id,audio,mixdrop,fembed,streamtape,warezcdn))
                    if lang:
                        lang2 = []
                        for _id,audio,mixdrop,fembed,streamtape,warezcdn in lang:
                            if str(audio) == '1' or str(audio) == 'Original':
                                audio = 'LEGENDADO'
                            elif str(audio) == '2' or str(audio) == 'Dublado':
                                audio  = 'DUBLADO'
                            else:
                                audio = 'UNKNOW'
                            if mixdrop == '3':                        
                                url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=mixdrop'%str(_id)
                                lang2.append(('MIXDROP', audio, url))
                            if fembed == '3':
                                url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=fembed'%str(_id)
                                lang2.append(('FEMBED', audio, url))                            
                            if streamtape == '3':
                                url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=streamtape'%str(_id)
                                lang2.append(('STREAMTAPE',audio,url))
                            if warezcdn == '3':
                                url = 'https://warezcdn.com/player/player.php?id=%s'%str(_id)
                                lang2.append(('CDN', audio, url))
                        if lang2:
                            for name, audio, url in lang2:
                                if name in ['MIXDROP', 'STREAMTAPE']:
                                    try:
                                        r = req.get(url,headers={'Referer': referer})
                                        src = r.text
                                        try:
                                            src = re.compile('window.location.href="(.*?)"').findall(src)[0]
                                        except:
                                            src = ''
                                        if src:
                                            try:
                                                sub = src.split('http')[2]
                                                sub = 'http%s'%sub
                                                try:
                                                    sub = sub.split('&')[0]
                                                except:
                                                    pass
                                                if not '.srt' in sub:
                                                    sub = ''                                            
                                            except:
                                                sub = ''
                                            try:
                                                src = src.split('?')[0]
                                            except:
                                                pass
                                            try:
                                                src = src.split('#')[0]
                                            except:
                                                pass                                                 
                                            name = name + ' - ' + audio
                                            servers.append((name,src,sub))
                                    except:
                                        pass
                                elif name == 'CDN':
                                    name = 'ALTERNATIVO' + ' - ' + audio
                                    servers.append((name,url,''))

        else:
            url = 'https://embed.warezcdn.com/filme/%s'%str(imdb)
            data = req.get(url,headers={'Referer': referer}).text
            audio_id = re.compile('<div class="selectAudioButton.+?" data-load-hosts="(.*?)">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
            if not audio_id:
                audio_id = []
                idioma = re.compile('<div class="selectAudio">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
                if idioma:
                    text = idioma[0].lower()
                    if 'dublado' in text:
                        lg = 'DUBLADO'
                    elif 'legendado' in text:
                        lg = 'LEGENDADO'
                    else:
                        lg = ''
                    if lg:
                        id_audio = re.compile('<div class="hostList active" data-audio-id="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
                        if id_audio:
                            audio_id.append((id_audio[0],lg))
            if audio_id:
                lang = {}
                for id, lg in audio_id:
                    if 'LEGENDADO' in lg:
                        lang[id]='LEGENDADO'
                    elif 'DUBLADO' in lg:
                        lang[id]='DUBLADO'
                hosts = re.compile('<div class="buttonLoadHost.+?" data-load-embed="(.*?)" data-load-embed-host="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
                if hosts:
                    for id, name in hosts:
                        lg=lang[id]
                        if name in ['mixdrop', 'streamtape']:
                            url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=%s'%(str(id),name)
                            try:
                                r = req.get(url,headers={'Referer': referer})
                                src = r.text
                                try:
                                    src = re.compile('window.location.href="(.*?)"').findall(src)[0]
                                except:
                                    src = ''
                                if src:
                                    try:
                                        sub = src.split('http')[2]
                                        sub = 'http%s'%sub
                                        try:
                                            sub = sub.split('&')[0]
                                        except:
                                            pass
                                        if not '.srt' in sub:
                                            sub = ''                                            
                                    except:
                                        sub = ''
                                    try:
                                        src = src.split('?')[0]
                                    except:
                                        pass
                                    try:
                                        src = src.split('#')[0]
                                    except:
                                        pass
                                    if name == 'streamtape':
                                        name = 'STREAMTAPE' + ' - ' + lg
                                    else:
                                        name = 'MIXDROP' + ' - ' + lg
                                    servers.append((name,src,sub))
                            except:
                                pass
                        elif name == 'warezcdn':
                            src = 'https://warezcdn.com/player/player.php?id=%s'%str(id)
                            name = 'ALTERNATIVO' + ' - ' + lg
                            servers.append((name,src,''))

        return servers

    def referer_player_animes(self):
        referer = ''
        try:
            r = req.get('https://onepod.inrupt.net/public/addon_oneplay/animes_oneplay.txt')
            src = r.text
            referer = re.findall('referer="(.*?)"', src)[0]
        except:
            pass
        return referer

    #### ANIMES ######
    def calendario(self,day):
        days = 'segunda, terca, quarta, quinta, sexta, sabado, domingo'
        api = '%s/api/'%self.site_anime
        headers = self.headers
        #headers.update({'Referer': 'https://meuanime.io/api/'})
        payload = {'action': 'show_lancamentos'}
        animes = []
        try:
            #r = requests.post(api,headers=headers,data=payload)
            r = req.post(api,headers=headers,replace_headers=True)
            d = r.json()
            for key in d[day].keys():
                anime = d[day][key]
                name = anime['title']
                iconimage = anime['thumbnail']
                url = anime['url']
                animes.append((name,iconimage,url))
        except:
            pass
        return animes

    def todos_animes(self,url=False):
        if not url:
            url = self.site_anime + '/lista-de-animes-online'
        headers = self.headers
        headers.update({'Referer': self.site_anime + '/'})
        itens = []
        next = False
        page = ''
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            animes = soup.find('div', class_=lambda x: x.startswith('ultAnisContainer')).find_all('div',class_=lambda x: x.startswith('ultAnisContainerItem'))
            for anime in animes:
                a = anime.find('a')
                href = a.get('href')
                name = a.find('div', {'class': 'aniInfos'}).find('div', {'class': 'aniNome'}).text
                name = name.strip()
                name = name.replace('\n', '').replace('\r', '')
                div_img = a.find('div', {'class': 'aniImg'})
                img = div_img.find('img').get('data-lazy-src', '')
                eps = div_img.find('div', {'class': 'aniEps'}).text
                try:
                    ep = eps.split('E')[0].replace('\n', '').replace('\r', '').replace(' ', '')
                except:
                    ep = False
                if ep:
                    if int(ep) > 0:
                        itens.append((name,href,img,url))
            try:
                next = soup.find('div', {'paginacao'}).find('a', {'next page-numbers'}).get('href', '')
                if not next:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass                    
            except:
                next = False
        except:
            pass
        return itens, next, page 

    def episodios_animes(self,url):
        headers = self.headers
        headers.update({'Referer': self.site_anime + '/'})
        itens = []
        next = False
        page = ''
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            episodios = soup.find('section', class_=lambda x: x.startswith('anime_videos_section')).find_all('div',class_=lambda x: x.startswith('ultEpsContainerItem'))
            for episodio in episodios:
                a = episodio.find('a')
                href = a.get('href')
                try:
                    img = a.find('div', {'class':'epImg'}).find('img').get('data-lazy-src', '')
                except:
                    img = ''
                ep = a.find('div', {'class': 'epInfos'}).find('div', {'class': 'epNum'}).text
                ep = ep.strip()
                itens.append((ep,href,img,url))
            try:
                #next = soup.find('div', {'paginacao'}).find_all('a', {'class': 'page-numbers'})[-1].get('href', '')
                next = soup.find('div', {'paginacao'}).find_all('a', {'class': 'page-numbers'})
                next = [next_page for next_page in next if not 'last' in next_page['class']][-1].get('href', '')
                current = soup.find('div', {'paginacao'}).find('a', {'class': 'page-numbers current page-numbers'}).get('href', '')
                if not next:
                    next = False
                elif next == current:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass                    
            except:
                next = False
        except:
            pass     
        return itens, next, page

    def resolve_player_animes(self,url):
        headers = self.headers
        headers.update({'Referer': self.referer_player_animes()})
        referer = url
        stream = ''
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            match = re.search(r'"file":"([^"]+)"', html)
            if match:
                stream = match.group(1).replace('\/', '/') + '|User-Agent=' + quote(self.CHROME_USER_AGENT) + '&Referer=' + quote(referer)
        except:
            pass
        return stream

    def opcoes_animes(self,url,referer):
        headers = self.headers
        headers.update({'Referer': referer})
        itens = []
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            players = soup.find_all('div', {'class': 'playerBox', 'id': lambda x: x and x.startswith('player_')})
            if players:
                for op, player in enumerate(players):
                    op = op + 1
                    name = 'OPÇÃO %s'%str(op)
                    try:
                        script = player.find('div', {'id': lambda x: x and x.startswith('player_')}).find('script', text=re.compile('file: ".*"'))
                        try:
                            stream = re.findall('file: "(.*)"', str(script))[0]
                        except:
                            stream = ''
                        if not stream:
                            stream = re.findall('file: "(.*)"', script.text)[0]                    
                    except:
                        try:
                            stream = player.find('video').get('src', '')
                        except:
                            stream = ''
                    if not stream:
                        stream = player.find('a').get('href', '')

                    if '.mp4' in stream:
                        stream = stream + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Referer='+ quote(self.site_anime + '/')
                        itens.append((name,stream))
                    else:
                        itens.append((name,stream))

        except:
            pass
        return itens

    def pesquisa_animes(self,url=None,pesquisa=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            #url = cls.site_anime + '/?s=' + quote(pesquisa).replace('%20', '+')
            url = self.site_anime + '/?s=' + pesquisa
        headers = self.headers
        headers.update({'Referer': self.site_anime + '/'})            
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            animes = soup.find('div', class_=lambda x: x.startswith('busca_container')).find_all('div',class_=lambda x: x.startswith('ultAnisContainerItem'))
            for anime in animes:
                a = anime.find('a')
                href = a.get('href')
                name = a.find('div', {'class': 'aniInfos'}).find('div', {'class': 'aniNome'}).text
                name = name.strip()
                name = name.replace('\n', '').replace('\r', '')
                div_img = a.find('div', {'class': 'aniImg'})
                img = div_img.find('img').get('data-lazy-src', '')
                itens.append((name,href,img,url))
            try:
                next = soup.find('div', {'paginacao'}).find('a', {'next page-numbers'}).get('href', '')
                if not next:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass
            except:
                next = False                 
        except:
            pass
        return itens, next, page

    # ### DESENHOS ######
    def todos_desenhos(self,next=False):
        if next:
            url = next
        else:
            url = self.site_desenho
        desenhos = []
        next_page = False
        page = ''
        try:
            headers = self.headers
            headers.update({'Referer': 'https://www.google.com/search?q=desenhosanimados+site'})
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            soup = self.soup(src)
            div = soup.find('div', {'id': 'animePost'})
            animes = div.find_all('section', {'class': 'animeItem'})
            pagination_list = soup.find('ol', class_='pagination')
            if animes:
                for anime in animes:
                    href = anime.find('a').get('href', '')
                    img = anime.find('img').get('data-lazy-src', '')
                    try:
                        name = anime.find('div', {'class': 'tituloAnime'}).text
                    except:
                        name = ''
                    if name:
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        name = name.upper()
                        name = '[B]' + name + '[/B]'
                        desenhos.append((name,href,img,url))
            if pagination_list:                
                try:
                    last_page_link = pagination_list.find_all('a')[-1].get('href')
                    page = last_page_link.split('/page/')[1]
                    next_page = last_page_link
                except:
                    pass                
        except:
            pass
        return desenhos,next_page,page 

    def desenhos_episodios(self,url,referer):
        episodios = []
        try:
            headers = self.headers
            headers.update({'Referer': referer})
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            soup = self.soup(src)
            div = soup.find_all('div', {'class': 'listaEp'})[-1]
            ep = div.find_all('section', {'class': 'episodioItem'})
            if ep:
                for i in ep:
                    href = i.find('a').get('href', '')
                    img = i.find('img').get('data-lazy-src', '')
                    try:
                        name = i.find('div', {'class': 'tituloEP'}).find('h3').text
                    except:
                        name = ''
                    if name:
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        name = name.upper()
                        name = '[B]' + name + '[/B]'                        
                        episodios.append((name,href,img,url))
        except:
            pass
        return episodios

    def resolve_desenho(self,url,referer):
        stream = ''
        headers = self.headers
        headers.update({'Referer': referer})
        try:
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            soup  = self.soup(src)
            div = soup.find('div', {'id': 'Link'})
            if div:
                page = div.find('a').get('href', '')
                if page:
                    headers.update({'Referer': 'https://guiavidaesaude.com/'})
                    r2 = req.get(page,headers=headers,replace_headers=True)
                    src = r2.text
                    find_stream = re.findall(r'"file":"(.*?)"', src)
                    if find_stream:
                        headers.update({'Origin': 'https://animesgames.net', 'Referer': 'https://animesgames.net/'})
                        page2 = find_stream[0].replace(r'\/', '/')
                        r3 = req.get(page2,headers=headers,replace_headers=True)
                        src3 = r3.text
                        m3u8_pattern = re.compile(r'https?://[^\s/$.?#].[^\s]*\.m3u8')
                        resolution_pattern = re.compile(r'RESOLUTION=(\d+x\d+)')
                        m3u8_links = m3u8_pattern.findall(src3)
                        resolutions = resolution_pattern.findall(src3)
                        max_resolution = 0
                        best_resolution_link = ""
                        for ordem,link in enumerate(m3u8_links):
                            if '.m3u8' in link:
                                try:
                                    link = link.split('http')[2]
                                    if link:
                                        link = 'http' + link
                                except:
                                    pass
                                resolution = resolutions[ordem]
                                width, height = map(int, resolution.split('x'))
                                if width * height > max_resolution:
                                    max_resolution = width * height
                                    best_resolution_link = link
                        if best_resolution_link:
                            best_resolution_link = 'https://oneplayhd.com/desenho_proxy.php?url=' + best_resolution_link
                            stream = best_resolution_link + self.append_headers(headers)
        except:
            pass
        return stream

    def get_oneplay_version(self):
        url = ''
        version = ''
        try:
            r = req.get(self.link_update)
            src = r.text
            url_zip = re.findall(r'url="(.*?)"', src)
            ver = re.findall(r'version="(.*?)"', src)
            if url_zip and ver:
                url = url_zip[0]
                version = ver[0]
        except:
            pass
        return url,version
    
    def decode_html(self,html):
        if six.PY2:
            try:
                html = html.encode('ascii', 'ignore')
            except:
                pass
        return html     

    def scrape_jogos(self):
        jogos = []
        try:
            url = 'https://oneplayhd.com/addon_oneplay/proxy/?url=' + quote(self.site_futebol)
            r = req.get(url, headers={'Referer': self.referer_futebol})
            referer = self.site_futebol
            src = r.text
            #src = self.decode_html(src)
            lista_jogos = re.findall(r'<div class="widget-line" style=".+?">.+?<a href="(.*?)" rel="bookmark".+?<div class="hora"><i class="fas fa-clock"></i>(.*?)</div>.+?<div class="info">.+?<img.+?.+?title="(.*?)" />.+?<span class="time">.+?</span></div>', src, flags=re.IGNORECASE|re.MULTILINE|re.DOTALL)
            if lista_jogos:
                try:
                    for link, hora, title in lista_jogos:
                        try:
                            hora = hora.decode('utf-8')
                        except:
                            pass
                        hora = hora.replace(' ', '')
                        try:
                            title = title.decode('utf-8')
                        except:
                            pass
                        title = title.replace("Assistir ", "").replace("ao vivo online ", "").replace(" HD", "").replace("assistir ", "").replace("Ao Vivo Online ", "").replace(" ao vivo", "").replace(" online", "").replace(" Grátis", "").replace("Grátis", "")
                        title = title + "-" + hora
                        jogos.append((title,link,referer))
                except:
                    pass
        except:
            pass
        return jogos

    def scrape_jogos_link(self,url,referer):
        final = []
        try:
            new_url = 'https://oneplayhd.com/addon_oneplay/proxy/?url=' + quote(url)
            r = req.get(new_url,headers={'Referer': referer})
            src = r.text
            #src = self.decode_html(src)
            if not '.m3u8' in src:
                try:
                    soup = self.soup(src)
                    a = soup.find_all("a", {"href": "javascript:void(0);"})
                except:
                    a = False
                if a:
                    for i in a:
                        link = i.get("data-url")
                        if 'cdn.php' in link:
                            if link.count('http') > 1:
                                try:
                                    link = link.split('http')[1]
                                    link = 'http' + link
                                except:
                                    pass                        
                            referer = url
                            link2 = self.scrape_jogos_link(link,referer=referer)
                            final.append(link2)
                            break
            if '.m3u8' in src and not final:
                links = re.findall('source: "(.*?)",', src)
                if links:
                    link = links[0] + '|User-Agent='+quote(self.EDGE_USER_AGENT)+'&Referer=' + quote(referer)
                else:
                    link = ''
                return link
            if final:
                return final[0]
        except:
            return                                                                                                                                                 

    # netcine
    def pesquisa_filmes(self,url,pesquisa):
        itens_pesquisa = []
        next_page = False
        page = ''
        if pesquisa:
            url = '%s/?s=%s'%(self.sitefilmes,quote_plus(pesquisa))
        else:
            if not self.sitefilmes in url:
                parsed_url = urlparse(url)
                host = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
                new_host = self.sitefilmes + '/'
                url = url.replace(host,new_host)             
        try:
            url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
            r = req.get(url)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')
                if '/tvshows/' in link:
                    name = '%s (Série)'%name
                else:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '%s (Filme) (HDCAM)'%name
                    else:
                        name = '%s (Filme)'%name
                if year:
                    name = '[B]%s (%s)[/B]'%(name,str(year))
                else:
                    name = '[B]%s[/B]'%name                
                itens_pesquisa.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return itens_pesquisa, next_page, page          



    # filmes
    def scraper_filmes(self, url=''):
        if not url:
            url = self.sitefilmes
        if not self.sitefilmes in url:
            parsed_url = urlparse(url)
            host = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
            new_host = self.sitefilmes + '/'
            url = url.replace(host,new_host)
        url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
        filmes = []
        next_page = False
        page = ''
        try:
            r = req.get(url)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')                
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                if year:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '[B]%s (%s) (HDCAM)[/B]'%(name,str(year))
                    else:
                        name = '[B]%s (%s)[/B]'%(name,str(year))
                else:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '[B]%s (HDCAM)[/B]'%name
                    else:
                        name = '[B]%s[/B]'%name
                filmes.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return filmes, next_page, page

    def scraper_series(self, url=''):
        if not url:
            url = self.sitefilmes + '/tvshows/'
        if not self.sitefilmes in url:
            parsed_url = urlparse(url)
            host = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
            new_host = self.sitefilmes + '/'
            url = url.replace(host,new_host)            
        url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
        series = []
        next_page = False
        page = ''
        try:
            r = req.get(url)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                if year:
                    name = '[B]%s (%s)[/B]'%(name,str(year))
                else:
                    name = '[B]%s[/B]'%name
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')
                series.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return series, next_page, page

    def scraper_temporadas_series(self,url):
        if not self.sitefilmes in url:
            parsed_url = urlparse(url)
            host = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
            new_host = self.sitefilmes + '/'
            url = url.replace(host,new_host)
        url_original = url       
        cache_url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
        list_seasons = []
        serie_name_final = ''
        img = ''
        fanart = ''        
        try:
            r = req.get(cache_url)
            src = r.text
            soup = self.soup(src)
            # info
            try:
                div_img = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'class': 'headingder'})
                fanart = div_img.find('div', class_=lambda x: x and 'lazyload' in x).get('data-bg', '')
                img = div_img.find('img', {'class': 'lazyload'}).get('data-src', '')
                try:
                    serie_name = div_img.find('div', {'class': 'datos'}).find('div', {'class': 'dataplus'}).find('h1').text
                    try:
                        serie_name = serie_name.decode('utf-8')
                    except:
                        pass
                    serie_name_final = '[B]:::: SÉRIE: %s ::::[/B]'%serie_name
                except:
                    pass
            except:
                pass
            s = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'id': 'cssmenu'}).find('ul').findAll('li', {'class': 'has-sub'})
            for n, i in enumerate(s):
                n += 1
                name = '[B]TEMPORADA %s[/B]'%str(n)
                season = str(n)
                list_seasons.append((season,name,url_original))
        except:
            pass
        return serie_name_final, img, fanart, list_seasons
    
    def scraper_episodios_series(self,url,season):
        cache_url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
        list_episodes = []
        serie_name_final = ''
        img = ''
        fanart = ''        
        try:
            r = req.get(cache_url)
            src = r.text
            soup = self.soup(src)
            # info
            try:
                div_img = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'class': 'headingder'})
                fanart = div_img.find('div', class_=lambda x: x and 'lazyload' in x).get('data-bg', '')
                img = div_img.find('img', {'class': 'lazyload'}).get('data-src', '')
                try:
                    serie_name = div_img.find('div', {'class': 'datos'}).find('div', {'class': 'dataplus'}).find('h1').text
                    try:
                        serie_name = serie_name.decode('utf-8')
                    except:
                        pass
                    serie_name_final = '[B]:::: SÉRIE: %s ::::[/B]'%serie_name
                except:
                    pass
            except:
                pass
            s = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'id': 'cssmenu'}).find('ul').findAll('li', {'class': 'has-sub'})
            for n, i in enumerate(s):
                n += 1
                if int(season) == n:
                    e = i.find('ul').findAll('li')
                    for n, i in enumerate(e):
                        n += 1
                        e_info = i.find('a')
                        link = e_info.get('href')
                        ep_name = e_info.find('span', {'class': 'datix'}).text
                        try:
                            ep_name = ep_name.decode('utf-8')
                        except:
                            pass
                        ep_name = ep_name.strip()
                        name_especial = '[B]%s - %s x %s - %s[/B]'%(serie_name,str(season),str(n),ep_name)
                        ep_name2 = '[B]%s - %s[/B]'%(str(n),ep_name)
                        list_episodes.append((ep_name2,name_especial,link))
                    break
        except:
            pass
        return serie_name_final, img, fanart, list_episodes
    

    def opcoes_filmes(self,url):
        opcoes = []
        if not self.sitefilmes in url:
            parsed_url = urlparse(url)
            host = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
            new_host = self.sitefilmes + '/'
            url = url.replace(host,new_host)        
        try:
            cache_url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
            r = req.get(cache_url)
            src = r.text
            soup = self.soup(src)
            player = soup.find('div', {'id': 'player-container'})
            botoes = player.find('ul', {'class': 'player-menu'})
            op = botoes.findAll('li')
            op_list = []
            if op:
                for i in op:
                    a = i.find('a')
                    id_ = a.get('href', '').replace('#', '')
                    op_name = a.text
                    try:
                        op_name = op_name.decode('utf-8')
                    except:
                        pass
                    op_name = op_name.replace(' 1', '').replace(' 2', '').replace(' 3', '').replace(' 4', '').replace(' 5', '')
                    op_name = op_name.strip()
                    op_name = op_name.upper()
                    op_list.append((op_name,id_))
            if op_list:
                for name, id_ in op_list:
                    iframe = player.find('div', {'class': 'play-c'}).find('div', {'id': id_}).find('iframe').get('src', '')
                    if not 'streamtape' in iframe:
                        link = self.sitefilmes + '/' + iframe
                    else:
                        link = iframe
                    opcoes.append((name,link))

        except:
            pass
        return opcoes
      
    
    def resolve_filmes(self,url):
        proxy = True
        #https://netcine.rs/media-player/nv32mono.php?n=Survive.N.Chicago.2023.720p.WEBRip.Dublado&p=filmes2023/1xbet
        stream = ''
        sub = ''
        if 'streamtape' in url:
            stream, sub = self.resolverurl(url)
        else:
            try:
                if not self.sitefilmes in url and 'netcine' in url:
                    parsed_url = urlparse(url)
                    host = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
                    new_host = self.sitefilmes + '/'
                    url = url.replace(host,new_host)
                ## verifica se a pagina ja é o player
                if proxy:
                    url_proxy = 'https://oneplayhd.com/addon_oneplay/proxy/netcine_proxy.php?url=' + quote(url)
                    r2 = req.get(url_proxy, headers={'User-Agent': self.EDGE_USER_AGENT, 'Referer': url})
                    src2 = r2.text
                    if 'http' in src2:
                        stream += src2
                else:
                    headers = {'User-Agent': self.EDGE_USER_AGENT, 'Referer': url, 'Cookie': 'XCRF%3DXCRF'}
                    r2 = req.get(url, headers=headers)
                    src2 = r2.text
                    last_url = r2.url
                    parsed_url = urlparse(last_url)
                    referer = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
                    headers.update({'Referer': referer})
                    regex_pattern = r'<source[^>]*\s+src="([^"]+)"'
                    alto = []
                    baixo = []
                    matches = re.findall(regex_pattern, src2)
                    for match in matches:
                        if 'ALTO' in match:
                            alto.append(match)
                        if 'alto' in match:
                            alto.append(match)
                        if 'BAIXO' in match:
                            baixo.append(match)
                        if 'baixo' in match:
                            baixo.append(match)
                    if alto:
                        stream += alto[-1] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(headers['Referer']) + '&Cookie=' + headers['Cookie']
                    elif baixo:
                        stream += baixo[-1] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(headers['Referer']) + '&Cookie=' + headers['Cookie'] 
                # se não for player buscar o player                   
                if not stream:                
                    cache_url = 'https://oneplayhd.com/addon_oneplay/cache/?url=' + quote(url)
                    r = req.get(cache_url)
                    src = r.text
                    soup = self.soup(src)
                    page = ''
                    streamtape = ''
                    try:
                        links = soup.find('div', {'class': 'geral'}).find('div', {'class': 'itens'}).findAll('a')
                        if links:
                            for link in links:
                                href = link.get('onclick', '')
                                if '/dist/' in href and not 'watchhd' in href:
                                    try:
                                        page = re.findall(r"href='(.*?)'", href)[0]
                                    except:
                                        pass
                                    break
                            for link in links:
                                href = link.get('onclick', '')
                                if '/dist/' in href and 'watchhd' in href:
                                    try:
                                        streamtape = re.findall(r"href='(.*?)'", href)[0]
                                    except:
                                        pass
                                    break                                                  
                    except:
                        pass
                    if not page:
                        iframe = soup.find('iframe').get('src', '')
                        if 'streamtape' in iframe:
                            stream, sub = self.resolverurl(iframe)
                    # abrir o player e pegar o link
                    if page and not streamtape and not stream:
                        if proxy:
                            url_proxy = 'https://oneplayhd.com/addon_oneplay/proxy/netcine_proxy.php?url=' + quote(page)
                            r2 = req.get(url_proxy, headers={'User-Agent': self.EDGE_USER_AGENT, 'Referer': url})
                            src2 = r2.text
                            if 'http' in src2:
                                stream += src2
                        else:
                            headers = {'User-Agent': self.EDGE_USER_AGENT, 'Referer': url, 'Cookie': 'XCRF%3DXCRF'}
                            r2 = req.get(page, headers=headers)
                            src2 = r2.text
                            last_url = r2.url
                            parsed_url = urlparse(last_url)
                            referer = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
                            headers.update({'Referer': referer})
                            regex_pattern = r'<source[^>]*\s+src="([^"]+)"'
                            alto = []
                            baixo = []
                            matches = re.findall(regex_pattern, src2)
                            for match in matches:
                                if 'ALTO' in match:
                                    alto.append(match)
                                if 'alto' in match:
                                    alto.append(match)
                                if 'BAIXO' in match:
                                    baixo.append(match)
                                if 'baixo' in match:
                                    baixo.append(match)
                            if alto:
                                stream += alto[-1] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(headers['Referer']) + '&Cookie=' + headers['Cookie']
                            elif baixo:
                                stream += baixo[-1] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(headers['Referer']) + '&Cookie=' + headers['Cookie']
                    elif streamtape and not stream:
                        url_proxy = 'https://oneplayhd.com/addon_oneplay/proxy/netcine_proxy2.php?url=' + quote(streamtape)
                        r2 = req.get(url_proxy, headers={'User-Agent': self.EDGE_USER_AGENT, 'Referer': url})
                        src2 = r2.text
                        soup = self.soup(src2)
                        iframe = soup.find('iframe').get('src', '')
                        if 'streamtape' in iframe:
                            stream, sub = self.resolverurl(iframe)
                    if not stream:
                        if page:
                            if proxy:
                                url_proxy = 'https://oneplayhd.com/addon_oneplay/proxy/netcine_proxy.php?url=' + quote(page)
                                r2 = req.get(url_proxy, headers={'User-Agent': self.EDGE_USER_AGENT, 'Referer': url})
                                src2 = r2.text
                                if 'http' in src2:
                                    stream += src2
                            else:
                                headers = {'User-Agent': self.EDGE_USER_AGENT, 'Referer': url, 'Cookie': 'XCRF%3DXCRF'}
                                r2 = req.get(page, headers=headers)
                                src2 = r2.text
                                last_url = r2.url
                                parsed_url = urlparse(last_url)
                                referer = '%s://%s/'%(parsed_url.scheme,parsed_url.netloc)
                                headers.update({'Referer': referer})
                                regex_pattern = r'<source[^>]*\s+src="([^"]+)"'
                                alto = []
                                baixo = []
                                matches = re.findall(regex_pattern, src2)
                                for match in matches:
                                    if 'ALTO' in match:
                                        alto.append(match)
                                    if 'alto' in match:
                                        alto.append(match)
                                    if 'BAIXO' in match:
                                        baixo.append(match)
                                    if 'baixo' in match:
                                        baixo.append(match)
                                if alto:
                                    stream += alto[-1] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(headers['Referer']) + '&Cookie=' + headers['Cookie']
                                elif baixo:
                                    stream += baixo[-1] + '|User-Agent=' + quote(headers['User-Agent']) + '&Referer=' + quote(headers['Referer']) + '&Cookie=' + headers['Cookie']
            except:
                pass
        return stream,sub
    
    def calendario(self,day):
        days = 'segunda, terca, quarta, quinta, sexta, sabado, domingo'
        api = '%s/api/'%self.site_anime
        headers = self.headers
        #headers.update({'Referer': 'https://meuanime.io/api/'})
        payload = {'action': 'show_lancamentos'}
        animes = []
        try:
            #r = requests.post(api,headers=headers,data=payload)
            r = req.post(api,headers=headers,replace_headers=True)
            d = r.json()
            for key in d[day].keys():
                anime = d[day][key]
                name = anime['title']
                iconimage = anime['thumbnail']
                url = anime['url']
                animes.append((name,iconimage,url))
        except:
            pass
        return animes

    def todos_animes(self,url=False):
        if not url:
            url = self.site_anime + '/lista-de-animes-online'
        headers = self.headers
        headers.update({'Referer': self.site_anime + '/'})
        itens = []
        next = False
        page = ''
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            animes = soup.find('div', class_=lambda x: x.startswith('ultAnisContainer')).find_all('div',class_=lambda x: x.startswith('ultAnisContainerItem'))
            for anime in animes:
                a = anime.find('a')
                href = a.get('href')
                name = a.find('div', {'class': 'aniInfos'}).find('div', {'class': 'aniNome'}).text
                name = name.strip()
                name = name.replace('\n', '').replace('\r', '')
                div_img = a.find('div', {'class': 'aniImg'})
                img = div_img.find('img').get('data-lazy-src', '')
                eps = div_img.find('div', {'class': 'aniEps'}).text
                try:
                    ep = eps.split('E')[0].replace('\n', '').replace('\r', '').replace(' ', '')
                except:
                    ep = False
                if ep:
                    if int(ep) > 0:
                        itens.append((name,href,img,url))
            try:
                next = soup.find('div', {'paginacao'}).find('a', {'next page-numbers'}).get('href', '')
                if not next:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass                    
            except:
                next = False
        except:
            pass
        return itens, next, page

    def episodios_animes(self,url):
        headers = self.headers
        headers.update({'Referer': self.site_anime + '/'})
        itens = []
        next = False
        page = ''
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            episodios = soup.find('section', class_=lambda x: x.startswith('anime_videos_section')).find_all('div',class_=lambda x: x.startswith('ultEpsContainerItem'))
            for episodio in episodios:
                a = episodio.find('a')
                href = a.get('href')
                try:
                    img = a.find('div', {'class':'epImg'}).find('img').get('data-lazy-src', '')
                except:
                    img = ''
                ep = a.find('div', {'class': 'epInfos'}).find('div', {'class': 'epNum'}).text
                ep = ep.strip()
                itens.append((ep,href,img,url))
            try:
                #next = soup.find('div', {'paginacao'}).find_all('a', {'class': 'page-numbers'})[-1].get('href', '')
                next = soup.find('div', {'paginacao'}).find_all('a', {'class': 'page-numbers'})
                next = [next_page for next_page in next if not 'last' in next_page['class']][-1].get('href', '')
                current = soup.find('div', {'paginacao'}).find('a', {'class': 'page-numbers current page-numbers'}).get('href', '')
                if not next:
                    next = False
                elif next == current:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass                    
            except:
                next = False
        except:
            pass     
        return itens, next, page

    def resolve_player_animes(self,url):
        headers = self.headers
        headers.update({'Referer': self.referer_player_animes()})
        referer = url
        stream = ''
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            match = re.search(r'"file":"([^"]+)"', html)
            if match:
                stream = match.group(1).replace('\/', '/') + '|User-Agent=' + quote(self.CHROME_USER_AGENT) + '&Referer=' + quote(referer)
        except:
            pass
        return stream

    # resolver animes
    def opcoes_animes(self,url,referer):
        headers = self.headers
        headers.update({'Referer': referer})
        itens = []
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            players = soup.find_all('div', {'class': 'playerBox', 'id': lambda x: x and x.startswith('player_')})
            if players:
                for op, player in enumerate(players):
                    op = op + 1
                    name = 'OPÇÃO %s'%str(op)
                    # try:
                    #     script = player.find('div', {'id': lambda x: x and x.startswith('player_')}).find('script', text=re.compile('file: ".*"'))
                    #     try:
                    #         stream = re.findall('file: "(.*)"', str(script))[0]
                    #     except:
                    #         stream = ''
                    #     if not stream:
                    #         stream = re.findall('file: "(.*)"', script.text)[0]                    
                    # except:
                    #     try:
                    #         stream = player.find('video').get('src', '')
                    #     except:
                    #         stream = ''
                    try:
                        stream = re.findall(r'file:.+?"(.*?)"', str(player))[0]
                    except:
                        stream = ''
                    if not stream:
                        stream = re.findall(r'src="([^"]+\.mp4)"', str(player))[0]                           
                    if not stream:
                        stream = player.find('a').get('href', '')
                    if '.mp4' in stream:
                        stream = stream + '|User-Agent='+ quote(headers['User-Agent']) + '&Referer='+ quote(self.site_anime + '/')
                        itens.append((name,stream))
                    else:
                        itens.append((name,stream))

        except:
            pass
        return itens

    def pesquisa_animes(self,url=None,pesquisa=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            #url = cls.site_anime + '/?s=' + quote(pesquisa).replace('%20', '+')
            url = self.site_anime + '/?s=' + pesquisa
        headers = self.headers
        headers.update({'Referer': self.site_anime + '/'})            
        try:
            #r = requests.get(url,headers=headers)
            r = req.get(url,headers=headers,replace_headers=True)
            html = r.text
            soup = self.soup(html)
            animes = soup.find('div', class_=lambda x: x.startswith('busca_container')).find_all('div',class_=lambda x: x.startswith('ultAnisContainerItem'))
            for anime in animes:
                a = anime.find('a')
                href = a.get('href')
                name = a.find('div', {'class': 'aniInfos'}).find('div', {'class': 'aniNome'}).text
                name = name.strip()
                name = name.replace('\n', '').replace('\r', '')
                div_img = a.find('div', {'class': 'aniImg'})
                img = div_img.find('img').get('data-lazy-src', '')
                itens.append((name,href,img,url))
            try:
                next = soup.find('div', {'paginacao'}).find('a', {'next page-numbers'}).get('href', '')
                if not next:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass
            except:
                next = False                 
        except:
            pass
        return itens, next, page

    def todos_desenhos(self,next=False):
        if next:
            url = next
        else:
            url = self.site_desenho
        desenhos = []
        next_page = False
        page = ''
        try:
            headers = self.headers
            headers.update({'Referer': 'https://www.google.com/search?q=desenhosanimados+site'})
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            soup = self.soup(src)
            div = soup.find('div', {'id': 'animePost'})
            animes = div.find_all('section', {'class': 'animeItem'})
            pagination_list = soup.find('ol', class_='pagination')
            if animes:
                for anime in animes:
                    href = anime.find('a').get('href', '')
                    img = anime.find('img').get('data-lazy-src', '')
                    try:
                        name = anime.find('div', {'class': 'tituloAnime'}).text
                    except:
                        name = ''
                    if name:
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        name = name.upper()
                        name = '[B]' + name + '[/B]'
                        desenhos.append((name,href,img,url))
            if pagination_list:                
                try:
                    last_page_link = pagination_list.find_all('a')[-1].get('href')
                    page = last_page_link.split('/page/')[1]
                    next_page = last_page_link
                except:
                    pass                
        except:
            pass
        return desenhos,next_page,page

    def desenhos_episodios(self,url,referer):
        episodios = []
        try:
            headers = self.headers
            headers.update({'Referer': referer})
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            soup = self.soup(src)
            div = soup.find_all('div', {'class': 'listaEp'})[-1]
            ep = div.find_all('section', {'class': 'episodioItem'})
            if ep:
                for i in ep:
                    href = i.find('a').get('href', '')
                    img = i.find('img').get('data-lazy-src', '')
                    try:
                        name = i.find('div', {'class': 'tituloEP'}).find('h3').text
                    except:
                        name = ''
                    if name:
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        name = name.upper()
                        name = '[B]' + name + '[/B]'                        
                        episodios.append((name,href,img,url))
        except:
            pass
        return episodios

    def resolve_desenho(self,url,referer):
        stream = ''
        headers = self.headers
        headers.update({'Referer': referer})
        try:
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            soup  = self.soup(src)
            div = soup.find('div', {'id': 'Link'})
            if div:
                page = div.find('a').get('href', '')
                if page:
                    headers.update({'Referer': 'https://guiavidaesaude.com/'})
                    r2 = req.get(page,headers=headers,replace_headers=True)
                    src = r2.text
                    find_stream = re.findall(r'"file":"(.*?)"', src)
                    if find_stream:
                        headers.update({'Origin': 'https://animesgames.net', 'Referer': 'https://animesgames.net/'})
                        page2 = find_stream[0].replace(r'\/', '/')
                        r3 = req.get(page2,headers=headers,replace_headers=True)
                        src3 = r3.text
                        m3u8_pattern = re.compile(r'https?://[^\s/$.?#].[^\s]*\.m3u8')
                        resolution_pattern = re.compile(r'RESOLUTION=(\d+x\d+)')
                        m3u8_links = m3u8_pattern.findall(src3)
                        resolutions = resolution_pattern.findall(src3)
                        max_resolution = 0
                        best_resolution_link = ""
                        for ordem,link in enumerate(m3u8_links):
                            if '.m3u8' in link:
                                try:
                                    link = link.split('http')[2]
                                    if link:
                                        link = 'http' + link
                                except:
                                    pass
                                resolution = resolutions[ordem]
                                width, height = map(int, resolution.split('x'))
                                if width * height > max_resolution:
                                    max_resolution = width * height
                                    best_resolution_link = link
                        if best_resolution_link:
                            #best_resolution_link = 'https://oneplayhd.com/desenho_proxy.php?url=' + best_resolution_link
                            best_resolution_link = 'https://oneplayhd.com/addon_oneplay/proxy/desenho_proxy.php?url=' + quote(best_resolution_link)
                            stream = best_resolution_link + self.append_headers(headers)
        except:
            pass
        return stream                                         

# desenhos, next, page = oneplay().todos_desenhos(next=False)
# print(desenhos)

#print(oneplay().opcoes_filmes('https://netcine.rs/episode/flash-1x01/'))

#print(oneplay().resolve_filmes('https://netcine.rs/media-player/nv32multi2.php?n=TDFURACOES2023DUB&p=filmes2023&id1=rd1ejROWAdIbq2w'))

# oneplay().scraper_episodios_series('https://netcine.rs/tvshows/loki/', '1')

##print(oneplay().resolve_filmes('https://netcine.rs/media-player/gc.php?n=01&p=theflash/01leg'))
        