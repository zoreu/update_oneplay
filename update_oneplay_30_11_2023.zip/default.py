# -*- coding: utf-8 -*-
from lib.plugin import *
from lib.scraper import oneplay
import six
if six.PY3:
    from urllib.parse import unquote_plus
else:
    from urllib import unquote_plus
import sys
if six.PY2:
    reload(sys)
    sys.setdefaultencoding('utf-8')

@route('/')
def index():
    set_content('movies')
    parental_password()
    oneplay().contador()
    update_oneplay()
    item({'name': '[B][COLOR aquamarine]:::[/COLOR]BEM-VINDOS AO ONEPLAY[COLOR aquamarine]:::[/COLOR][/B]', 'iconimage': icon, 'description': oneplay().descricao_addon()},folder=True)
    item({'name': '[B]VIP[/B]','iconimage': icons('vip'), 'description': oneplay().vip_descricao()}, destiny='/vip', folder=True)
    item({'name': '[B]TV[/B]','iconimage': icons('tv'), 'description': 'Area para canais, opções:\nServidor1, Servidor 2 e Servidor 3'}, destiny='/tv', folder=True)
    item({'name': '[B]FILMES E SÉRIES[/B]','iconimage': icons('filmeseseries'), 'description': ''}, destiny='/filmes_series', folder=True)
    item({'name': '[B]ANIMES[/B]','iconimage': icons('animes'), 'description': ''}, destiny='/animes', folder=True)
    item({'name': '[B]DESENHOS[/B]','iconimage': icons('desenhos'), 'description': ''}, destiny='/desenhos', folder=True)
    item({'name': '[B]DOAÇÃO[/B]','iconimage': icons('doacao'), 'description': ''}, destiny='/donate', folder=True)    
    item({'name': '[B]CONFIGURAÇÕES[/B]','iconimage': icons('configuracoes'), 'description': ''}, destiny='/settings', folder=True)
    end(cache=False)
    set_view('List')

@route('/vip')
def vip():
    baixar_apk()

@route('/tv')
def tv():
    oneplay().contador()
    update_oneplay()
    item({'name': '[B]SERVIDOR 1[/B]','iconimage': icons('tv'), 'description': ''}, destiny='/tv_servidor1', folder=True)
    item({'name': '[B]SERVIDOR 2 (ONEPLAY PROXY)[/B]','iconimage': icons('tv'), 'description': ''}, destiny='/tv_servidor2', folder=True)
    item({'name': '[B]SERVIDOR 3 (JOGOS AO VIVO)[/B]','iconimage': icons('tv'), 'description': ''}, destiny='/tv_servidor3', folder=True)
    end()
    set_view('WideList')    

@route('/tv_servidor1')
def tv_servidor1():
    oneplay().contador()
    update_oneplay()
    servidor1_categoria()

@route('/tv_servidor2')
def tv_servidor2():
    oneplay().contador()
    servidor2_opcoes()

@route('/tv_servidor3')
def tv_servidor3():
    oneplay().contador()
    update_oneplay()
    jogos = oneplay().scrape_jogos()
    if jogos:
        set_content('videos')
        for name,link,referer in jogos:
            name = '[B]' + name.upper() + '[/B]'
            item({'name': name.encode('utf-8', 'ignore'),'iconimage': icon, 'url': link, 'referer': referer, 'description': ''}, destiny='/play_jogos', folder=False)
        end(cache=False)
        set_view('WideList')
    else:
        notify('Jogos Indisponiveis')

@route('/play_jogos')
def play_jogos(param):
    url = unquote_plus(param.get('url', ''))
    referer = unquote_plus(param.get('referer', ''))
    if url and referer:
        notify('Aguarde...')
        try:
            new_url = oneplay().scrape_jogos_link(url,referer)
            if new_url:
                param.update({'url': new_url})
                proxy_player(param)
                #normal_player(param)
            else:
                notify('Stream indisponivel')
        except:
            notify('Stream indisponivel')     
    

@route('/tv_servidor1_abrir')
def tv_servidor1_abrir(param):
    oneplay().contador()
    update_oneplay()
    tv_servidor1_abrir_(param)

@route('/tv_lista')
def abrir_lista(param):
    oneplay().contador()
    update_oneplay()
    exibir_lista(param)

@route('/exibir_grupo_lista')
def grupo_lista(param):
    update_oneplay()
    exibir_grupo_m3u(param)

@route('/play_canais')
def play_canais(param):
    proxy_player(param)

@route('/play_normal')
def play(param):
    normal_player(param)

@route('/filmes_series')
def filmes_series():
    oneplay().contador()
    update_oneplay()
    item({'name': '[B]PESQUISAR[/B]','iconimage': icons('pesquisar'), 'description': ''}, destiny='/pesquisar_filmes', folder=True)
    item({'name': '[B]FILMES[/B]','iconimage': icons('filmes'), 'description': ''}, destiny='/filmes', folder=True)
    item({'name': '[B]SÉRIES[/B]','iconimage': icons('series'), 'description': ''}, destiny='/series', folder=True)
    end()
    set_view('WideList')


@route('/pesquisar_filmes')
def pesquisar_filmes(param):
    pesquisa = unquote_plus(param.get('pesquisa', ''))
    url = unquote_plus(param.get('next', ''))
    if pesquisa:
        itens_pesquisa, next_page, page = oneplay().pesquisa_filmes(url=url,pesquisa='')
    else:
        pesquisa = search()
        if pesquisa:
            itens_pesquisa, next_page, page = oneplay().pesquisa_filmes(url='',pesquisa=pesquisa)
        else:
            return
    if itens_pesquisa:
        set_content('movies')
        for name, iconimage, link in itens_pesquisa:
            if '/tvshows/' in link:
                item({'name': name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'description': '', 'url': link}, destiny='/temporada_serie', folder=True)
            else:
                item({'name': name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'description': '', 'url': link}, destiny='/opcoes_filmes', folder=False)
        if next_page:
            item({'name': 'Pagina %s'%page,'iconimage': icons('proximo'), 'description': '', 'pesquisa': pesquisa, 'next': next_page}, destiny='/pesquisar_filmes', folder=True)                
        end()
        set_view('Wall')
    else:
        notify('Nenhum item encontrado!')               


@route('/filmes')
def filmes(param):
    oneplay().contador()
    update_oneplay()
    url = unquote_plus(param.get('next', ''))
    filmes, next_page, page = oneplay().scraper_filmes(url)
    if filmes:
        set_content('movies')
        for name, iconimage, link in filmes:
            item({'name': name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'description': '', 'url': link, 'playable': 'true'}, destiny='/opcoes_filmes', folder=False)
        if next_page:
            item({'name': 'Pagina %s'%page,'iconimage': icons('proximo'), 'description': '', 'next': next_page}, destiny='/filmes', folder=True)
        end()
        set_view('Wall')

@route('/series')
def series(param):
    oneplay().contador()
    update_oneplay()
    url = unquote_plus(param.get('next', ''))
    series, next_page, page = oneplay().scraper_series(url)
    if series:
        set_content('tvshows')
        for name, iconimage, link in series:
            item({'name': name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'description': '', 'url': link}, destiny='/temporada_serie', folder=True)
        if next_page:
            item({'name': 'Pagina %s'%page,'iconimage': icons('proximo'), 'description': '', 'next': next_page}, destiny='/series', folder=True)
        end()
        set_view('Wall')

@route('/temporada_serie')
def temporada_serie(param):
    oneplay().contador()
    url = unquote_plus(param.get('url', ''))
    serie_name, iconimage, fanart, s = oneplay().scraper_temporadas_series(url)
    if s:
        set_content('tvshows')
        item({'name': serie_name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'fanart': fanart, 'description': ''}, destiny='', folder=True)
        for season,name,link in s:
            item({'name': name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'fanart': fanart, 'description': '', 'url': link, 'season': season}, destiny='/episodios_serie', folder=True)
        end()
        set_view('List')

@route('/episodios_serie')
def episodios_serie(param):
    oneplay().contador()
    update_oneplay()
    url = unquote_plus(param.get('url', ''))
    season = unquote_plus(param.get('season', ''))
    serie_name, iconimage, fanart, e = oneplay().scraper_episodios_series(url,season)
    if e:
        set_content('tvshows')
        item({'name': serie_name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'fanart': fanart, 'description': ''}, destiny='', folder=True)
        for ep_name,name_especial,link in e:
            item({'name': ep_name.encode('utf-8', 'ignore'),'iconimage': iconimage, 'fanart': fanart, 'description': '', 'url': link, 'fullname': name_especial.encode('utf-8', 'ignore'), 'playable': 'true'}, destiny='/opcoes_filmes', folder=False)
        end()
        set_view('List')

@route('/opcoes_filmes')
def opcoes_filmes(param):
    name_movie = unquote_plus(param.get('fullname', ''))
    if not name_movie:
        name_movie = unquote_plus(param.get('name', ''))
    url = unquote_plus(param.get('url', ''))
    if name_movie and url:
        op_ = oneplay().opcoes_filmes(url)
        items_options = [name2 for name2,link in op_]
        try:
            op = dialog.select('SELECIONE UMA OPÇÃO:', items_options)
            if op >= 0:
                link = op_[op][1]
                stream,sub = oneplay().resolve_filmes(link)
                if stream:
                    param.update({'name': name_movie, 'url': stream})
                    normal_player(param)
                else:
                    notify('Stream indisponivel') 
        except:
            notify('Stream indisponivel') 

@route('/animes')      
def menu_animes():
    oneplay().contador()
    update_oneplay()
    set_content('tvshows')
    item({'name': '[B]PESQUISAR[/B]','iconimage': icons('pesquisar'), 'description': ''}, destiny='/pesquisar_anime', folder=True)
    item({'name': '[B]TODOS OS ANIMES[/B]','iconimage': icons('animes'), 'description': ''}, destiny='/todos_animes', folder=True)
    end()
    set_view('WideList')

@route('/pesquisar_anime')
def pesquisar_anime(param):
    pesquisa = unquote_plus(param.get('pesquisa', ''))
    next = unquote_plus(param.get('next', ''))
    if not next:
        next = False
    if not pesquisa:
        pesquisa = search2()
        if pesquisa:
            itens, next, page = oneplay().pesquisa_animes(next,pesquisa=pesquisa)
        else:
            return
    else:
        itens, next, page = oneplay().pesquisa_animes(next,pesquisa=False)
    if itens:
        set_content('tvshows')
        for anime in itens:
            name,href,iconimage,referer = anime
            try:
                name = name.decode('utf-8')
            except:
                pass
            try:
                name = name.replace('&#8211;', '-')
            except:
                pass
            name = '[B]' + name.upper() + '[/B]'
            item({'name': name.encode('utf-8', 'ignore'), 'url': href, 'iconimage': iconimage}, destiny='/episodio_anime', folder=True)
        if next:
            name = '[B]PAGINA %s[/B]'%str(page)
            item({'name': name, 'action': 'pesquisa_anime', 'pesquisa': pesquisa.encode('utf-8', 'ignore'), 'next': next, 'iconimage': icons('proximo')}, destiny='/pesquisar_anime', folder=True)
        end()
        set_view('WideList')

@route('/todos_animes')
def todos_animes(param):
    oneplay().contador()
    update_oneplay()
    next = unquote_plus(param.get('next', ''))
    if not next:
        next = False
    itens, next, page = oneplay().todos_animes(next)
    if itens:
        set_content('tvshows')
        for anime in itens:
            name,href,iconimage,referer = anime
            try:
                name = name.decode('utf-8')
            except:
                pass
            try:
                name = name.replace('&#8211;', '-')
            except:
                pass
            name = '[B]' + name.upper() + '[/B]'
            item({'name': name.encode('utf-8', 'ignore'), 'url': href, 'iconimage': iconimage}, destiny='/episodio_anime', folder=True)
        if next:
            name = '[B]PAGINA %s[/B]'%str(page)
            item({'name': name, 'action': 'menu_todos_animes', 'next': next, 'iconimage': icons('proximo')}, destiny='/todos_animes', folder=True)
        end()
        set_view('WideList')


@route('/episodio_anime')
def episodio_anime(param):
    oneplay().contador()
    update_oneplay()
    next = unquote_plus(param.get('next', unquote_plus(param.get('url', ''))))
    if not next:
        next = False
    itens, next, page = oneplay().episodios_animes(next)
    if itens:
        set_content('tvshows')
        for episodio in itens:
            name,href,iconimage,referer = episodio
            try:
                name = name.decode('utf-8')
            except:
                pass
            name = '[B]' + name.upper() + '[/B]'
            item({'name': name.encode('utf-8', 'ignore'), 'url': href, 'referer': referer, 'iconimage': iconimage, 'playable': 'true'}, destiny='/play_animes', folder=False)
        if next:
            name = '[B]PAGINA %s[/B]'%str(page)
            item({'name': name, 'action': 'episodio_anime', 'next': next, 'iconimage': icons('proximo')}, destiny='/episodio_anime', folder=True)
        end()
        set_view('WideList')


@route('/play_animes')
def play_animes(param):
    url = unquote_plus(param.get('url', ''))
    referer = unquote_plus(param.get('referer', ''))
    if url and referer:
        itens = oneplay().opcoes_animes(url,referer)
        if itens:
            items_options = [name2 for name2,href in itens]
            op = dialog.select('SELECIONE UMA OPÇÃO', items_options)
            if op >= 0:
                stream = itens[op][1]
                if not '.mp4' in stream:
                    stream = oneplay().resolve_player_animes(stream)
                if stream:
                    param.update({'url': stream})
                    normal_player(param)
                else:
                    notify('STREAM INDISPONIVEL')
        else:
            notify('STREAM INDISPONIVEL')


@route('/desenhos')
def desenhos(param):
    oneplay().contador()
    update_oneplay()
    next = unquote_plus(param.get('next', ''))
    if not next:
        next = False
    desenhos, next_page, page = oneplay().todos_desenhos(next=next)
    if desenhos:
        set_content('tvshows')
        for desenho in desenhos:
            name,href,img,referer = desenho
            item({'name': name.encode('utf-8', 'ignore'), 'iconimage': img, 'description': '', 'url': href, 'referer': referer}, destiny='/desenhos_episodios', folder=True)
        if next_page:
            name_next = '[B]Pagina %s[/B]'%page
            item({'name': name_next.encode('utf-8', 'ignore'), 'action': 'desenhos','iconimage': icons('proximo'), 'description': '', 'next': next_page}, destiny='/desenhos', folder=True)
        end()
        set_view('Wall')            

@route('/desenhos_episodios')
def desenhos_episodios(param):
    oneplay().contador()
    update_oneplay()
    url = unquote_plus(param.get('url', ''))
    referer = unquote_plus(param.get('referer', ''))                  
    if url and referer:
        episodios = oneplay().desenhos_episodios(url,referer)
        if episodios:
            set_content('tvshows')
            for episodio in episodios:
                name,href,img,referer = episodio
                item({'name': name.encode('utf-8', 'ignore'), 'iconimage': img, 'description': '', 'url': href, 'referer': referer, 'playable': 'true'}, destiny='/play_desenho', folder=False)           
            end()
            set_view('WideList') 


@route('/play_desenho')
def play_desenho(param):
    url = unquote_plus(param.get('url', ''))
    referer = unquote_plus(param.get('referer', ''))
    if url and referer:
        stream = oneplay().resolve_desenho(url,referer)
        if stream:
            param.update({'url': stream})
            normal_player(param)
        else:
            notify('Stream indisponivel')

@route('/settings')
def settings():
    open_settings()

@route('/donate')
def donate():
    donate_question()

@route('/setpassword')
def setpassword():
    parental_password()
    setnewpassaord()   
